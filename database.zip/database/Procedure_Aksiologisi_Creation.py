import tkinter as tk
import mysql.connector



from config import ID
from config import id_sm







conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()



def execute_procedure_aksiologisi_creation():
    n_isbn = entry_n_isbn.get()
    n_bathmologia = entry_n_bathmologia.get()
    n_kritiki = entry_n_kritiki.get()

    try:
        cursor.execute("INSERT INTO `Aksiologisi` (`id_xristi`, `isbn`, `bathmologia`, `kritiki`, hm_dhmiourgias, hm_egrisis, `last_update`) VALUES (%s, %s, %s, %s, current_timestamp, NULL, current_timestamp)", (ID, n_isbn, n_bathmologia, n_kritiki))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)

window = tk.Tk()
window.title("Νεα Αξιολογηση")


label_n_isbn = tk.Label(window, text="isbn:")
label_n_isbn.pack()
entry_n_isbn = tk.Entry(window)
entry_n_isbn.pack()

label_n_bathmologia = tk.Label(window, text="Βαθμολογια (1-5) :")
label_n_bathmologia.pack()
entry_n_bathmologia = tk.Entry(window)
entry_n_bathmologia.pack()

label_n_kritiki = tk.Label(window, text="Κριτικη :")
label_n_kritiki.pack()
entry_n_kritiki = tk.Entry(window)
entry_n_kritiki.pack()

button_execute_aksiologisi = tk.Button(window, text="Run", command=execute_procedure_aksiologisi_creation)
button_execute_aksiologisi.pack()

window.mainloop()
