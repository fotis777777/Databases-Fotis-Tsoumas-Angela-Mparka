import tkinter as tk
import mysql.connector

from config import ID
from config import id_sm


conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()


window = tk.Tk()
window.title("Διαδικασιες Χρηστων")



def execute_password_update():
    n_password = entry_password.get()

    try:
        cursor.execute("UPDATE XRISTES set password=%s where id_xristi=%s;", (n_password, ID))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)

label_ak = tk.Label(window, text="Αλλαγη Κωδικου")
label_ak.pack()

label_np = tk.Label(window, text="Νεος Κωδικος: ")
label_np.pack()
entry_password = tk.Entry(window)
entry_password.pack()

button_execute_aksiologisi = tk.Button(window, text="Run", command=execute_password_update)
button_execute_aksiologisi.pack()




def execute_Kratisi_Creation():
    isbn = entry_ck.get()

    try:
        cursor.execute("""INSERT INTO Daneismoi_Kratiseis
                        (id_xristi, isbn, hm_kratisis, hm_daneismou, hm_epistrofis, last_update)
                        VALUES
                        (%s, %s, CURRENT_TIMESTAMP, null, null, current_timestamp)""", (ID, isbn))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)

label_ck = tk.Label(window, text="Δημιουργια Κρατησης")
label_ck.pack()

label_ck = tk.Label(window, text="ISBN: ")
label_ck.pack()
entry_ck = tk.Entry(window)
entry_ck.pack()

button_execute_aksiologisi = tk.Button(window, text="Run", command=execute_Kratisi_Creation)
button_execute_aksiologisi.pack()




def execute_Kratisi_Deletion():
    isbn = entry_dk.get()

    try:
        cursor.execute("""DELETE FROM Daneismoi_Kratiseis
                        WHERE id_xristi = %s AND isbn = %s and hm_daneismou is null; """, (ID, isbn))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)

label_dk = tk.Label(window, text="Διαγραφη Κρατησης")
label_dk.pack()

label_dk = tk.Label(window, text="ISBN: ")
label_dk.pack()
entry_dk = tk.Entry(window)
entry_dk.pack()

button_execute_aksiologisi = tk.Button(window, text="Run", command=execute_Kratisi_Deletion)
button_execute_aksiologisi.pack()




window.mainloop()
