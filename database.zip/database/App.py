import tkinter as tk
import mysql.connector
import os
import subprocess
import configparser


current_directory = os.path.dirname(os.path.abspath(__file__))

cnx = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="library"
)


cursor = cnx.cursor()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Library App")
        self.geometry("600x400")

        self.stack = []
        self.current_frame = None

        self.show_login()

    def show_login(self):
        login_frame = LoginFrame(self)
        self.stack.append(login_frame)
        self.show_frame(login_frame)

    def show_frame(self, frame):
        if self.current_frame:
            self.current_frame.pack_forget()

        self.current_frame = frame
        self.current_frame.pack(fill=tk.BOTH, expand=True)

    def go_back(self):
        if len(self.stack) > 1:
            self.stack.pop()
            prev_frame = self.stack[-1]
            self.show_frame(prev_frame)


class LoginFrame(tk.Frame):
    def __init__(self, master):
        super().__init__(master)

        self.master = master

        self.label_username = tk.Label(self, text="Username:")
        self.label_username.pack()

        self.entry_username = tk.Entry(self)
        self.entry_username.pack()

        self.label_password = tk.Label(self, text="Password:")
        self.label_password.pack()

        self.entry_password = tk.Entry(self, show="*")
        self.entry_password.pack()

        self.button_login = tk.Button(self, text="Login", command=self.login)
        self.button_login.pack(pady=10)

    def login(self):
        username = self.entry_username.get()
        password = self.entry_password.get()

        if self.check_login(username, password):
            role = self.get_role(username)
            ID = self.get_ID(username, password)
            id_sm = self.get_id_sm(ID)
            env = dict(os.environ, ID=str(ID), id_sm=str(id_sm))
            config = configparser.ConfigParser()
            config_file_path = 'config.py'

            with open(config_file_path, 'w') as config_file:
                config_file.write(f"ID = {ID}\n")
                config_file.write(f"id_sm = {id_sm}\n")

            frame2 = Frame2(self.master, username, role, ID, id_sm)
            self.master.stack.append(frame2)
            self.master.show_frame(frame2)
        else:
            print("Wrong username or password!")

    def check_login(self, username, password):
        query = "SELECT id_xristi, is_admin, stud_prof FROM Xristes WHERE username = %s AND password = %s"
        cursor.execute(query, (username, password))
        user_info = cursor.fetchone()

        if user_info:
            print("Login successful!")
            return True
        else:
            print("Invalid username or password.")
            return False

    def get_ID(self, username, password):
        query = "SELECT id_xristi FROM Xristes WHERE username = %s AND password = %s ;"
        cursor.execute(query, (username, password))
        id_xristi = cursor.fetchone()

        global ID
        ID = int(str(id_xristi)[1:-2])
        print("ID:", ID)
        return ID

    def get_id_sm(self, ID):
        query = '''SELECT asm.id_sxolikis_monadas
               FROM Anhkei_SM asm
               inner join Xristes x ON asm.id_xristi = x.id_xristi
               WHERE asm.id_xristi = %s ;'''
        cursor.execute(query, (ID,))
        result = cursor.fetchone()

        global id_sm
        id_sm = int(str(result)[1:-2])
        print("id_sm: ", id_sm)
        return id_sm

    def get_role(self, username):
        query = "SELECT id_xristi, is_admin, stud_prof FROM Xristes WHERE username = %s"
        cursor.execute(query, (username,))
        user_info = cursor.fetchone()

        id_xristi, is_admin, stud_prof = user_info

        query = "SELECT * FROM Einai_Xeiristis WHERE id_xristi = %s"
        cursor.execute(query, (id_xristi,))
        result = cursor.fetchone()

        if result:
            role = "janitor"
        elif is_admin == 1:
            role = "admin"
        elif is_admin == 0 and stud_prof == 0:
            role = "student"
        elif is_admin == 0 and stud_prof == 1:
            role = "teacher"
        else:
            role = "unknown"

        return role

class Frame2(tk.Frame):
    def __init__(self, master, username, role, ID, id_sm):
        super().__init__(master)

        label = tk.Label(self, text="Login Successful!")
        label.pack(pady=10)

        self.username = username
        self.role = role
        self.id = ID
        self.id_sm = id_sm

        button_back = tk.Button(self, text="Log-out", command=self.master.go_back)
        button_back.pack(side=tk.LEFT, padx=5)

        button_next = tk.Button(self, text="Enter the App", command=self.go_to_frame3)
        button_next.pack(side=tk.LEFT)

    def go_to_frame3(self):
        frame3 = Frame3(self.master, self.role, self.id, self.id_sm)
        self.master.stack.append(frame3)
        self.master.show_frame(frame3)


class Frame3(tk.Frame):
    def __init__(self, master, role, ID, id_sm):
        super().__init__(master)

        label = tk.Label(self, text="Identity Card")
        label.pack(pady=10)

        self.label = tk.Label(self, text="ID, Username, Name, Surname, Birth, Job, Role, JanitorDate, School")
        self.label.pack()

        self.text_output = tk.Text(self, font=("Arial", 9), width=40, height=20)
        self.text_output.pack(side="left", fill="both", expand=True)

        cursor.execute("SELECT * from USER_DATA where id_xristi = %s;", (ID,))
        result = cursor.fetchall()
        cursor.nextset()

        self.text_output.delete("1.0", tk.END)
        for item in result:
            self.text_output.insert(tk.END, f"{item}\n")

        button_back = tk.Button(self, text="Back", command=self.master.go_back)
        button_back.pack(side=tk.LEFT, padx=5)


        if role == "admin":
            button_next = tk.Button(self, text="Continue", command=self.go_to_frame4)
            button_next.pack(side=tk.LEFT)

        if role == "janitor":
            button_next = tk.Button(self, text="Continue", command=self.go_to_frame5)
            button_next.pack(side=tk.LEFT)

        if role == "teacher":
            button_next = tk.Button(self, text="Continue", command=self.go_to_frame6)
            button_next.pack(side=tk.LEFT)

        if role == "student":
            button_next = tk.Button(self, text="Continue", command=self.go_to_frame7)
            button_next.pack(side=tk.LEFT)

    def go_to_frame4(self):
        frame4 = Frame4(self.master)
        self.master.stack.append(frame4)
        self.master.show_frame(frame4)

    def go_to_frame5(self):
        frame5 = Frame5(self.master)
        self.master.stack.append(frame5)
        self.master.show_frame(frame5)

    def go_to_frame6(self):
        frame6 = Frame6(self.master)
        self.master.stack.append(frame6)
        self.master.show_frame(frame6)

    def go_to_frame7(self):
        frame7 = Frame7(self.master)
        self.master.stack.append(frame7)
        self.master.show_frame(frame7)


class Frame4(tk.Frame):
    def __init__(self, master):
        super().__init__(master)

        label = tk.Label(self, text="Administrator menu")
        label.pack(pady=10)

        button_back = tk.Button(self, text="Back", command=self.master.go_back)
        button_back.pack(side=tk.LEFT, padx=5)

        button_next = tk.Button(self, text="Admin Views", command=self.open_script)
        button_next.pack(side=tk.LEFT)

        button_next = tk.Button(self, text="Αποδοχες Χειριστων", command=self.open_script2)
        button_next.pack(side=tk.LEFT)

        button_next = tk.Button(self, text="Δημιουργια Σχολειου", command=self.open_script3)
        button_next.pack(side=tk.LEFT)

        button_next = tk.Button(self, text="Επεξεργασια Σχολειου", command=self.open_script4)
        button_next.pack(side=tk.LEFT)

        button_next = tk.Button(self, text="Next", state=tk.DISABLED)
        button_next.pack(side=tk.LEFT)

        button_next = tk.Button(self, text="Continue as User", command=self.go_to_frame6)
        button_next.pack(side=tk.LEFT)

    def go_to_frame6(self):
        frame6 = Frame6(self.master)
        self.master.stack.append(frame6)
        self.master.show_frame(frame6)

    def open_script(self):
        script_path = os.path.join(current_directory, "Admin_Script.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")

    def open_script2(self):
        script_path = os.path.join(current_directory, "Procedure_Xeiristis_Approve.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")

    def open_script3(self):
        script_path = os.path.join(current_directory, "Procedure_SM_Creation.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")

    def open_script4(self):
        script_path = os.path.join(current_directory, "Procedure_SM_Update.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")

    def go_to_frame4(self):
        frame4 = Frame4(self.master)
        self.master.stack.append(frame4)
        self.master.show_frame(frame4)


class Frame5(tk.Frame):
    def __init__(self, master):
        super().__init__(master)

        label = tk.Label(self, text="Janitor Menu")
        label.pack(pady=10)

        button_back = tk.Button(self, text="Back", command=self.master.go_back)
        button_back.pack(side=tk.LEFT, padx=5)

        button_next = tk.Button(self, text="Δημιουργια Χρηστη", command=self.open_script)
        button_next.pack(side=tk.LEFT)

        button_next1 = tk.Button(self, text="Δημιουργια Βιβλιου", command=self.open_script1)
        button_next1.pack(side=tk.LEFT)

        button_next2 = tk.Button(self, text="Ενημερωση Βιβλιου", command=self.open_script2)
        button_next2.pack(side=tk.LEFT)

        button_next3 = tk.Button(self, text="Open Views 1", command=self.open_script3)
        button_next3.pack(side=tk.LEFT)

        button_next4 = tk.Button(self, text="Open Views 2", command=self.open_script4)
        button_next4.pack(side=tk.LEFT)

        button_next5 = tk.Button(self, text="Open Procedures", command=self.open_script5)
        button_next5.pack(side=tk.LEFT)

        button_next6 = tk.Button(self, text="Next", state=tk.DISABLED)
        button_next6.pack(side=tk.LEFT)

        button_next = tk.Button(self, text="Continue as User", command=self.go_to_frame6)
        button_next.pack(side=tk.LEFT)

    def go_to_frame6(self):
        frame6 = Frame6(self.master)
        self.master.stack.append(frame6)
        self.master.show_frame(frame6)

    def open_script(self):
        script_path = os.path.join(current_directory, "Procedure_Xristis_Creation.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")

    def open_script1(self):
        script_path = os.path.join(current_directory, "Procedure_Biblio_Creation.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")

    def open_script2(self):
        script_path = os.path.join(current_directory, "Procedure_Biblio_Update.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")

    def open_script3(self):
        script_path = os.path.join(current_directory, "Janitor_Script.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")

    def open_script4(self):
        script_path = os.path.join(current_directory, "Janitor_Script2.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")

    def open_script5(self):
        script_path = os.path.join(current_directory, "Procedures_Xeiristes.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm}")
        else:
            print("Script file not found!")


class Frame6(tk.Frame):
    def __init__(self, master):
        super().__init__(master)

        label = tk.Label(self, text="Teacher Menu")
        label.pack(pady=10)

        button_back = tk.Button(self, text="Back", command=self.master.go_back)
        button_back.pack(side=tk.LEFT, padx=5)

        button_next = tk.Button(self, text="Open Views", command=self.open_script)
        button_next.pack(side=tk.LEFT)

        button_next2 = tk.Button(self, text="Open Procedures", command=self.open_script2)
        button_next2.pack(side=tk.LEFT)

        button_next2 = tk.Button(self, text="Edit Personal Data", command=self.open_script3)
        button_next2.pack(side=tk.LEFT)

        button_next3 = tk.Button(self, text="Δημιουργια Αξιολογησης", command=self.open_script4)
        button_next3.pack(side=tk.LEFT)


        button_next = tk.Button(self, text="Next", state=tk.DISABLED)
        button_next.pack(side=tk.LEFT)

    def open_script(self):
        script_path = os.path.join(current_directory, "Xristes_Script.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm} {id_sm}")
        else:
            print("Script file not found!")

    def open_script2(self):
        script_path = os.path.join(current_directory, "Procedures_Teachers.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm} {id_sm}")
        else:
            print("Script file not found!")

    def open_script3(self):
        script_path = os.path.join(current_directory, "Procedure_Xristis_Update.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm} {id_sm}")
        else:
            print("Script file not found!")

    def open_script4(self):
        script_path = os.path.join(current_directory, "Procedure_Aksiologisi_Creation.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm} {id_sm}")
        else:
            print("Script file not found!")




class Frame7(tk.Frame):
    def __init__(self, master):
        super().__init__(master)

        label = tk.Label(self, text="Student Menu")
        label.pack(pady=10)

        button_back = tk.Button(self, text="Back", command=self.master.go_back)
        button_back.pack(side=tk.LEFT, padx=5)

        button_next = tk.Button(self, text="Open Views", command=self.open_script)
        button_next.pack(side=tk.LEFT)

        button_next2 = tk.Button(self, text="Open Procedures", command=self.open_script2)
        button_next2.pack(side=tk.LEFT)

        button_next3 = tk.Button(self, text="Δημιουργια Αξιολογησης", command=self.open_script4)
        button_next3.pack(side=tk.LEFT)

        button_next = tk.Button(self, text="Next", state=tk.DISABLED)
        button_next.pack(side=tk.LEFT)

    def open_script(self):
        script_path = os.path.join(current_directory, "Xristes_Script.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm} {id_sm}")
        else:
            print("Script file not found!")

    def open_script2(self):
        script_path = os.path.join(current_directory, "Procedures_Students.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm} {id_sm}")
        else:
            print("Script file not found!")

    def open_script4(self):
        script_path = os.path.join(current_directory, "Procedure_Aksiologisi_Creation.py")
        if os.path.isfile(script_path):
            os.system(f"python {script_path} {ID} {id_sm} {id_sm}")
        else:
            print("Script file not found!")



if __name__ == "__main__":
    app = App()
    app.mainloop()
