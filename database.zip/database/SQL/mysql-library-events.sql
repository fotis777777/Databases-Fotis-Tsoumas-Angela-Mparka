SET GLOBAL event_scheduler = ON;

DELIMITER $$

CREATE EVENT `allagh_katastashs` 
ON SCHEDULE 
EVERY 5 SECOND 
STARTS CURRENT_TIMESTAMP
DO 
BEGIN
    DECLARE pk_id INT;
    
    SELECT dk.id_DK INTO pk_id
    FROM daneismoi_kratiseis dk
    INNER JOIN diathesima_antitupa da ON dk.isbn = da.isbn
    WHERE dk.anamonh = '1' AND da.ar_diathesimwn > 0  AND da.id_sxolikis_monadas = (  select id_sxolikis_monadas
                                                                                      from anhkei_sm
                                                                                      where id_xristi=dk.id_xristi)
    ORDER BY dk.hm_kratisis
    LIMIT 1;

    IF pk_id IS NOT NULL THEN
        UPDATE daneismoi_kratiseis
        SET hm_kratisis = CURRENT_TIMESTAMP(), anamonh = '0'
        WHERE id_DK = pk_id;
    END IF;
END$$

DELIMITER ;

 

-- με την επιστροφη του βιβλιου θα ενημερωνονται τα διαθεσιμα-δανεισμενα αντιτυπα
-- με την ακυρωση ενεργης κρατησης        -  ""  -

-- AYTA ΠΡΕΠΕΙ ΝΑ ΞΑΝΑ ΕΝΗΜΕΡΩΝΟΝΤΑΙ ΜΕΤΑ ΑΥΤΟ ΑΠΟ ΑΥΤΟ ΤΟ UPDATE



CREATE EVENT `automath_akyrwsh_krathshs` 
ON SCHEDULE 
EVERY 1 DAY
STARTS (now())
DO
      delete from  Daneismoi_Kratiseis
      where (select DATE_SUB(now(),INTERVAL 7 DAY)) > hm_kratisis and hm_daneismou is null and hm_epistrofis is null ;

 