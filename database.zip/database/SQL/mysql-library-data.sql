

-- table Kathgories



Insert into Kathgories (`id_kathgorias`,`onoma_kathgorias`,`last_update`) Values ('1','klasikh_logotexnia','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('2','mythistorhma','2020-04-18 22:00:35');

Insert into Kathgories
(`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('3','pagkosmia_logotexnia','2020-04-18 22:00:35');

Insert into Kathgories
Values
('4','poihsh','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('5','episthmes','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('6','iatrikh','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('7','koinwnikes_kai_anthrwpistikes_episthmes','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('8','oikonomika','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('9','paidagwgika','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('10','texnologia','2020-04-18 22:00:35');

Insert into Kathgories
(`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('11','psyxologia','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('12','aytoveltiwsh','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('13','thrhskia','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('14','efhvika','2020-04-18 22:00:35');

Insert into Kathgories
 (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
Values
('15','egktyklopaidies','2020-04-18 22:00:35');

--Insert into Kathgories
-- (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
--Values
--('16','ekpaideytikoi xartes','2020-04-18 22:00:35');
--Insert into Kathgories
-- (`id_kathgorias`,`onoma_kathgorias`,`last_update`)
--Values
--('17','leksika','2020-04-18 22:00:35');



-- table Suggrafeis

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('1','Luigi Pirandello','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('2','Macray Sylvia','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('3','kamilo xose thela','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('4','Lev Nikolaevic Tolstoj','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('5','George Orwell','2020-04-18 21:00:35');


Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('6','Vladimir Nabokov','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('7','tom robins','2020-04-18 21:00:35');


Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('8','dhmhtrhs aggelatos','2020-04-18 21:00:35');


Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('9','Benjamin Labatut','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('10','tzenh kourea','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('11','P.Terzidhs','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('12','E.Krasanakh','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('13','B.Xatzikos','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('14','Paul J. Deitel','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('15','Andrew Matthews','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('16','Alexander Schmemann','2020-04-18 21:00:35');

Insert into Suggrafeis
 (`id_suggrafea`,`onoma_suggrafea`,`last_update`)
Values
('17','Judith Hann','2020-04-18 21:00:35');



-- table Biblia

Insert into Biblia
(`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9600339732','xaos','kastaniwth','ellhnikh','300','Tο 1984 οι αδελφοί Tαβιάνι γύρισαν την ωραιότερη ίσως κινηματογραφική ταινία τους, το σενάριο της οποίας βασίστηκε σε έξι διηγήματα του Λουίτζι Πιραντέλο.',null,'2020-04-18 23:00:35');

Insert into Biblia
(`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9606263347','psyxes ston xrono','phgh','ellhnikh','300','H Γαλάτεια Άσνε κατάλαβε πως είναι διαφορετική αρκετά νωρίς στη µικρή ζωή της. Κατάλαβε, επίσης, πως εάν ήθελε να επιβιώσει, έπρεπε να κρατάει το στόµα της κλειστό. Να υπακούει.',null,'2020-04-18 23:00:35');

Insert into Biblia
(`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9600304408','oikogeneia paskoual ntouarte','kastaniwth','ellhnikh','300','Όταν εμφανίστηκε "Η οικογένεια του Πασκουάλ Ντουάρτε", στα 1942, μια νέα ώθηση δόθηκε στην ισπανική λογοτεχνία: ξαναγύρισε σ` έναν κόσμο λαϊκό και αγροτικό, που οι χαρακτήρες του ήταν άνθρωποι πρωτόγονοι κι αυθεντικοί.',null,'2020-04-18 23:00:35');

Insert into Biblia
(`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9603789151','polemos kai eirhnh','patakh','ellhnikh','300','Ο Λέον Τολστόι (1828-1910) έγραψε το «Πόλεμος και Ειρήνη» μέσα σε έξι χρόνια.',null,'2020-04-18 23:00:35');


Insert into Biblia
(`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('960410912X','h farma twn zwwn','wkeanida','ellhnikh','300','Η επανάσταση στη Φάρμα του Αρχοντικού δεν έχει προηγούμενο! Οι άνθρωποι δεν θα είναι πλέον τα αφεντικά. ',null,'2020-04-18 23:00:35');


Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9603250880','gelio sto skotadi','arga','ellhnikh','300','`Μια φορά κι έναν καιρό ζούσε στο Βερολίνο της Γερμανίας κάποιος ονόματι Αλμπίνους. Επρόκειτο για πλούσιο, αξιοσέβαστο, ευτυχισμένο άνθρωπο.',null,'2020-04-18 23:00:35');


Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9605210231','to arwma tou oneirou','aiolos','ellhnikh','300','Το "Άρωμα του ονείρου" είναι ένα έπος που αρχίζει στα δάση της αρχαίας Βοημίας και δεν τελειώνει παρά απόψε, στις εννιά η ώρα το βράδυ (ώρα Παρισιού).',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('0140188223','Lolita','Penguin Books','english','300','In this Readers" Guide, Christine Clegg examines the critical history of "Lolita" through a broad range of interpretations.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9600112754','ergo dionusiou solwmoy','Gutenberg ','ellhnika','300','Η προκείμενη μονογραφία για το έργο του Διον. Σολωμού εντάσσεται στο πλαίσιο ερευνητικού σχεδίου.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9607089243','dromoi koinoi','etairia meleths','ellhnika','300','Ένα βράδυ, πριν από μερικά χρόνια, σε μια συγκέντρωση του «Μνήμονα» στην οδό Ζωσίμου.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9600118833','logotexnia kai zografikh','Gutenberg ','ellhnika','300','Από την εποχή της διατύπωσης του Σιμωνίδη του Κείου όπως τη διέσωσε ο Πλούταρχος, ότι η ζωγραφική είναι σιωπηλή ποίηση και η ποίηση ομιλούσα εικόνα.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9602367725','fwnh ths mnhmhs','livanhs','ellhnika','300','ΦΩΝΗ ΤΗΣ ΜΝΗΜΗΣ',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('6185598078','na katalaboyme ton kosmo','dwma','ellhnika','300','Η δημιουργία του ομορφότερου χρώματος που είδε ποτέ ο άνθρωπος οδηγεί σε ένα από τα φονικότερα δηλητήρια της ιστορίας.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('6185598167','lithos ths trelas','dwma','ellhnika','300','Τα τερατουργήματα και τα θαύματα της επιστήμης και της τεχνολογίας μάς παραλύουν· παλεύουμε να κρατηθούμε στην επιφάνεια παρά τα βίαια κύματα που σπρώχνει ασταμάτητα κατά πάνω μας η κοινωνική οργή·',null,'2020-04-18 23:00:35');


Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9606656128','dhmosia ygeia','med','ellhnika','300','Η ολοένα αυξανόμενη σημασία της δημόσιας υγείας καθιστά αναγκαία την απόκτηση ενός βασικού κορμού γνώσεων, τόσο από τους λειτουργούς υγείας όσο και από τους σπουδαστές του σχετικού χώρου.',null,'2020-04-18 23:00:35');


Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9600221448','dhmosia ygeia sthn prvtobathmia ygeia','papazhsh','ellhnika','300','Η Δημόσια Υγεία και γενικότερα η Γενική Ιατρική τα τελευταία χρόνια αποκτούν μια κρίσιμη θέση στη λειτουργία του Συστήματος Υγείας και του Οικονομικού Συστήματος σε κρατικό και διεθνές επίπεδο.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9607745116','dioikhsh anthrwpinwn porwn','Rosili','ellhnika','300','Οι επιχειρήσεις και οι οργανισμοί έχουν στρέψει σήμερα το ενδιαφέρον τους περισσότερο παρά ποτέ άλλοτε στη Διοίκηση Ανθρωπίνων Πόρων.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9605950014','management','sygxrwnh','ellhnika','300','Ο όρος «Μάνατζμεντ» περιλαμβάνει το σύνολο των ενεργειών που είναι απαραίτητες για την αποτελεσματική πηδαλιούχηση των διαδικασιών απόδοσης σε μια επιχείρηση ή οργανισμό (Steinmann και Schreyoegg, 1997).',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9606674665','management2','sygxrwnh','ellhnika','300','Η βελτίωση της ανταγωνιστικής ικανότητας μιας επιχείρησης, αποτελεί ύψιστη προτεραιότητα γι" αυτήν.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9608165776','management3','sygxrwnh','ellhnika','300','Καταγράφει και αναλύει τις κυριότερες τάσεις και τα πλέον εύχρηστα εργαλεία της επιστήμης του Mάνατζμεντ',null,'2020-04-18 23:00:35');


Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9609227201','psyxologia paidiou kai efhvou','E.Krasanakh','ellhnika','300','Ψυχολογία παιδιού και εφήβου',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('0609227201','oi fovoi twn efhvwn','idiwtikh','ellhnika','300','Οι φόβοι των εφήβων',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('1609227201','psyxologia tou paidiou','idiwtikh','ellhnika','300','Ψυχολογία παιδιού',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9604182528','Matlab gia episthmones','tziola','ellhnika','300','Το Matlab είναι μια υψηλού επιπέδου γλώσσα τεχνικού προγραμματισμού και ένα αλληλεπιδραστικό περιβάλλον για την ανάλυση στοιχείων και την ανάπτυξη αλγορίθμων και εφαρμογών.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9604188798','Matlab','tziola','ellhnika','300','Εισαγωγή στις Πράξεις με το Matlab, Πολυώνυμα – Πίνακες – Γραμμικά Συστήματα, Πράξεις με Ανώτερα Μαθηματικά, Μετασχηματισμοί & Σειρές, Γραφικές Παραστάσεις, Συστήματα Ελέγχου, Ευστάθεια Συστημάτων',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('960512680X','C++ ','Gkiourdas M.','ellhnika','300','Εκατομμύρια σπουδαστές και επαγγελματίες σε όλο τον κόσμο μαθαίνουν προγραμματισμό και ανάπτυξη λογισμικού με βιβλία, βίντεο LiveLessonsΤΜ και ηλεκτρονικές εκδόσεις της Dietel.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('0132990547','Android how to Program ','Prentice Hall','english','300','The Deitels" App-Driven, Live Code Approach is simply the best way to master Android programming! ',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('0133807800','Java how to Program','Pearson','english','300','Note: You are purchasing a standalone product; MyProgrammingLab does not come packaged with this content.  ',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9603642983','akou thn kardia sou','dioptra','ellhnika','300','Άκου την καρδιά σου και ανακάλυψε:Πώς σκέφτονται οι πραγματικά ευτυχισμένοι άνθρωποι.Γιατί οι πλούσιοι αποκτούν χρήματα, ακόμα και τυχαία.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9603643440','akou thn kardia tou efhvou','dioptra','ellhnika','300','Ένα βιβλίο για γονείς, εφήβους και εκπαιδευτικούς.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('1260116123','First Aid for the USMLE Step 1','McGraw-Hill Education','english','300','Publisher"s Note: Products purchased from Third Party sellers are not guaranteed by the publisher for quality, authenticity, or access to any online entitlements included with the product.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9600328390','pws na kaneis filous','kastaniwth','ellhniuka','300','Το σημαντικότερο είναι να καταλάβεις ότι ΑΝ ΘΕΛΕΙΣ ΦΙΛΙΕΣ, ΕΣΥ ΠΡΕΠΕΙ ΠΡΩΤΑ ΝΑ ΕΙΣΑΙ ΦΙΛΟΣ.',null,'2020-04-18 23:00:35');

Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9603281417','h panagia','akritas','ellhniuka','300','Με την παρούσα έκδοση ολοκληρώνεται η τριλογία «Βίωση της Πίστης», που αποτελείται από ομιλίες του π. Αλεξάνδρου Σμέμαν.',null,'2020-04-18 23:00:35');


Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9603280860','eortologio','akritas','ellhniuka','300',' Το βιβλίο αυτό είναι μια συλλογή από κηρύγματα, που αναφέρονται σε όλο σχεδόν το εκκλησιαστικό έτος.',null,'2020-04-18 23:00:35');


Insert into Biblia
 (`isbn`,`titlos`,`ekdoths`,`glwssa`,`selides`,`perilipsi`,`eikona`,`last_update`)
Values
('9607243048','anakalyptw thn episthmh','ereunhtes','ellhniuka','300','Μια πρωτότυπη και συναρπαστική ξενάγηση στον κόσμο της Επιστήμης και των πειραμάτων για μικρούς και μεγάλους.',null,'2020-04-18 23:00:35');




-- table Exei_grapsei

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('1','9600339732','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('2','9606263347','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('3','9600304408','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('4','9603789151','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('5','960410912X','2020-04-18 21:30:35');


Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('6','9603250880','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('7','9605210231','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('6','0140188223','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('8','9600112754','2020-04-18 21:30:35');


Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('8','9607089243','2020-04-18 21:30:35');


Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('8','9600118833','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('8','9602367725','2020-04-18 21:30:35');


Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('9','6185598078','2020-04-18 21:30:35');


Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('9','6185598167','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('10','9606656128','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('10','9600221448','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('11','9607745116','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('11','9605950014','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('11','9606674665','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('11','9608165776','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('12','9609227201','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('12','0609227201','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('12','1609227201','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('13','9604182528','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('13','9604188798','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('14','960512680X','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('14','0132990547','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('14','0133807800','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('15','9603642983','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('15','9603643440','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('15','1260116123','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('15','9600328390','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('16','9603281417','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('16','9603280860','2020-04-18 21:30:35');

Insert into Exei_grapsei
 (`id_suggrafea`,`isbn`,`last_update`)
Values
('17','9607243048','2020-04-18 21:30:35');


-- table Anhkei

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('1','9600339732','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('2','9600339732','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('3','9600339732','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('2','9606263347','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('1','9600304408','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('2','9600304408','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('1','9603789151','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('3','9603789151','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('1','960410912X','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('3','960410912X','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('2','9603250880','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('3','9603250880','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('3','9605210231','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('3','0140188223','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('4','9600112754','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('7','9607089243','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('7','9600118833','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('1','9602367725','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('5','6185598078','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('3','6185598078','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('3','6185598167','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('5','6185598167','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('6','9606656128','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('7','9606656128','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('6','9600221448','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('8','9607745116','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('8','9605950014','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('9','9605950014','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('8','9606674665','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('8','9608165776','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('7','9608165776','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('5','9608165776','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('11','9609227201','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('9','9609227201','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('14','9609227201','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('14','0609227201','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('11','0609227201','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('11','1609227201','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('5','9604182528','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('10','9604182528','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('10','9604188798','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('5','9604188798','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('9','9604188798','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('9','960512680X','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('10','960512680X','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('10','0132990547','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('10','0133807800','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('12','9603642983','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('11','9603643440','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('12','9603643440','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('14','9603643440','2020-04-18 21:40:35');


Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('6','1260116123','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('14','9600328390','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('12','9600328390','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('11','9600328390','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('13','9603281417','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('13','9603280860','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('15','9607243048','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('5','9607243048','2020-04-18 21:40:35');

Insert into Anhkei
 (`id_kathgorias`,`isbn`,`last_update`)
Values
('14','9607243048','2020-04-18 21:40:35');

-- table Sxoliki_Monada

INSERT INTO `Sxoliki_Monada`
(`id_sxolikis_monadas`, `onomasia_sm`, `TK`, `Polh`, `Thlefwno`, `email`, `onoma_dieuthunti`, `last_update`)
VALUES
('1', 'jacobi.com', '0', 'Stokeshaven', '0', 'price61@example.com', 'Mrs. Janiya Rempel III', '2020-04-18 21:45:35');

INSERT INTO `Sxoliki_Monada`
(`id_sxolikis_monadas`, `onomasia_sm`, `TK`, `Polh`, `Thlefwno`, `email`, `onoma_dieuthunti`, `last_update`)
VALUES
('2', 'quitzonschulist.com', '0', 'New Pearlieton', '0', 'fae.haley@example.com', 'Dr. Arvid Collins', '2020-04-18 21:45:35');

INSERT INTO `Sxoliki_Monada`
(`id_sxolikis_monadas`, `onomasia_sm`, `TK`, `Polh`, `Thlefwno`, `email`, `onoma_dieuthunti`, `last_update`)
VALUES
('3', 'fritsch.net', '0', 'Port Lillaport', '2082571528', 'juliet.casper@example.net', 'Lane Doyle', '2020-04-18 21:45:35');

INSERT INTO `Sxoliki_Monada`
(`id_sxolikis_monadas`, `onomasia_sm`, `TK`, `Polh`, `Thlefwno`, `email`, `onoma_dieuthunti`, `last_update`)
VALUES
('4', 'thiel.info', '0', 'Joshualand', '17', 'parker.aaliyah@example.com', 'Prof. Alison Satterfield', '2020-04-18 21:45:35');

INSERT INTO `Sxoliki_Monada`
(`id_sxolikis_monadas`, `onomasia_sm`, `TK`, `Polh`, `Thlefwno`, `email`, `onoma_dieuthunti`, `last_update`)
VALUES
('5', 'williamson.info', '0', 'Rexfort', '535', 'gerard.beier@example.com', 'Dr. Naomi Welch', '2020-04-18 21:45:35');




-- table Diathesima_Antitupa
-- Καθε σχολικη μοναδα έχει στην βιβλιοθηκη της καθε βιβλιο απο 5 αντιτυπα

INSERT INTO `Diathesima_Antitupa`
    (select 1 , isbn , '2020-04-18 22:45:35 ', 0 , 5
     from Biblia );

INSERT INTO `Diathesima_Antitupa`
    (select 2 , isbn , '2020-04-18 22:45:35 ', 0 , 5
     from Biblia );

INSERT INTO `Diathesima_Antitupa`
    (select 3 , isbn , '2020-04-18 22:45:35 ', 0 , 5
     from Biblia );

INSERT INTO `Diathesima_Antitupa`
    (select 4 , isbn , '2020-04-18 22:45:35 ', 0 , 5
     from Biblia );

INSERT INTO `Diathesima_Antitupa`
    (select 5 , isbn , '2020-04-18 22:45:35 ', 0 , 5
     from Biblia );



-- table Xristes
-- προκαθοριζουμε απο την αρχη ποιοι χρηστες θα ειναι μαθητες και ποιοι εκπαιδευτικοι. Οι πρωτοι 20 θα ειναι εκπαιδευτικοι και οι υπολοιποι θα ειναι μαθητρες.
-- Απο τωρα ανα 4 καθηγητες στην σειρα  θα ανηκουν σε αντιστοιχη σχολικη μοναδα και ο 1ος απο αυτους θα είναι ο αντιστοιχος χειρηιστης. Πχ οι 1 , 5 , 9 , 13 , 17
-- θα ειναι χειριστες σε καθε σχολικη μοναδα αντιστοιχα
-- διαχειριστης ειναι ο 61 , οπου ορισαμε is_admin = 1 .
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('1', 'tmann', 'fbfb89fcc6f4284e36c3f33ea334bef7f204265d',  'Terence', 'Predovic', '1970-10-10', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('2', 'ryanokon', 'f8dd8fb24e5bb4a28fe24215b8fc147282b55e11',  'Gay', 'Lueilwitz', '1972-11-11', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('3', 'andy63', '1802191b13298699154e425dc3f9476157c7edcd',  'Howard', 'Sipes', '1965-02-02', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('4', 'marlen.schroeder', 'a78b54829559f00cfaa6b369522989939911c12e',  'Buster', 'Murray', '1988-05-13', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('5', 'mauricio26', '60cf8beebfc4af26b0f2d7bb02bfdb628dfb760a',  'Twila', 'Becker', '1989-08-24', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('6', 'isanford', '3374312867a3deb9f8f97b4b7ad7624127b1e713',  'Wendell', 'Hirthe', '1981-05-15', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('7', 'alexis.mcglynn', 'af93ba189a0534a641bb59cb73cf7c4ea95a656e',  'Hunter', 'Morissette', '1969-01-26', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('8', 'destinee26', 'fcb94e96f6ff984d74830483f88b3ecb23442852',  'Dan', 'Luettgen', '1970-10-17', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('9', 'chase16', 'f14dcb3a4262bf4087cccdd48a59293142f0de84',  'Brady', 'Jones', '1970-10-18', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('10', 'hahn.belle', '45ee6f12c80eb04973fb7583c41cdc22d0682899',  'Jess', 'Ernser', '1982-11-19', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('11', 'uriel85', '37cca91c83fdf21037e0148dcd339bd01713acc3',  'Rashad', 'Ortiz', '1983-10-02', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('12', 'koelpin.pat', '0ff1d6fd1a52177a741c52fa799122e8920df62a',  'Laurie', 'Crona', '1967-02-21', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('13', 'kaleigh.klocko', '48aef4456fbbe3268147d8df88bb3701599c5d49',  'Frederik', 'Harber', '1990-10-22', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('14', 'tjones', '68739fbd113bc4faf70765cd6a2bb75475e5f373',  'Ethyl', 'DuBuque', '1986-10-23', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('15', 'langworth.alfred', 'a654ea28a499328007abaf55cf2006405946360f',  'Hilton', 'Kohler', '1974-10-24', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('16', 'terry.noemy', '3866eaf8d64d6d4d3d4b492a827d7748ec928cb3',  'Braxton', 'Murazik', '1989-10-15', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('17', 'ankunding.larry', '0d738eacb08b3ea97b286ab834ead627e273c2ef',  'Russell', 'Jones', '1980-07-08', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('18', 'narciso12', '53286a176f71a8fdcda3977cbbef1617ae00ea40',  'Lupe', 'Blick', '1990-09-27', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('19', 'cristal.zemlak', '349e15417e63743e064b89cc54564412e7404743',  'Lorenza', 'Nikolaus', '1967-11-08', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('20', 'nschmitt', 'f2ff75126088f200ee4a6119648bb37ae36b032c',  'Durward', 'Paucek', '1968-05-26', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('21', 'ross.goyette', '7a72cefeb4d86d1d3384a7bbab27595127cd99c8',  'Rebeka', 'Waters', '2010-10-10', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('22', 'macejkovic.terrell', '8826ba7e90a1753867525aea089a32feabf5064b',  'Lorenza', 'Cremin', '2010-10-11', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('23', 'janet.nicolas', '3db47c77a2cfce3b56557609633df89def1b4dbd',  'Dillan', 'Ondricka', '2010-10-12', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('24', 'towne.lilyan', '83c254a88456e70b45a541762956ddcd88d4fef8',  'Jaden', 'Fisher', '2010-10-13', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('25', 'frida65', 'b361ff15ae4d90012e53ab000a145bc684087e81',  'Brionna', 'Hane', '2010-10-14', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('26', 'zetta76', 'abd52f61559a054ac830035eada3cbe9712db807',  'Misael', 'Hilpert', '2010-10-15', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('27', 'purdy.lisette', 'aa132a180fd5c5a87152aa80a3b2eadc0c354cd4',  'Aleen', 'Medhurst', '2010-10-16', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('28', 'funk.joyce', '87bdb8be961b98b797ef98c7e5fccc344a988736', 'Brandi', 'Ondricka', '2010-10-17', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('29', 'stanley37', 'b4316306d6908e465dc6986d9688254c78580d24', 'Garett', 'Ward', '2010-10-18', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('30', 'fparker', '30e8253a00d83b4c89f5a2fedf375ecff3a056b1',  'Audie', 'Kling', '2010-10-19', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('31', 'lisandro.champlin', 'eed58e373b79a235892e028943a47a08d451744f',  'Ewald', 'Koch', '2010-10-20', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('32', 'jasen75', '1bdb1e2116126614fd54bfddccdcb6d517665981',  'Lester', 'Abernathy', '2010-10-21', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('33', 'yschmitt', 'd071b735a0ac4d55c97e35f5985ff1ab748e77ef', 'Zula', 'Schneider', '2010-10-22', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('34', 'isai66', 'ffd1442c9a7976d9465ead49980e0cd53574f1ac',  'Hubert', 'Graham', '2010-10-23', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('35', 'cletus59', '15a4b05c867d73823417db846b32fa3ad65a2b59',  'Clemens', 'Armstrong', '2010-10-24', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('36', 'maggio.alta', '528d659e0ae434a1657bd0592f1ff1ffe80257b1', 'Nikki', 'Predovic', '2010-10-25', 0, 0,'2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('37', 'o\hara.ruthie', 'a901a373d7d654633b4c836d519547d0fbb45da4',  'Esmeralda', 'Rau', '2010-10-26', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('38', 'sjaskolski', '1b7827b37f9ae4920a886f2002b614c7f76f7c7e',  'Sienna', 'Rice', '2010-10-27', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('39', 'marisa.larson', '88a0f98a4fc13455902a29e7facbcd2464930152',  'Candida', 'Stiedemann', '2010-10-28', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('40', 'odie60', '4a7cf52f76303b04d3d41dbeff64be829f212c1f',  'Candida', 'Feeney', '2010-11-09', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('41', 'rocky41', 'f73de16c632408c5ff828aca55091f0082ca1b9f',  'Wayne', 'Monahan', '2010-11-10', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('42', 'terrell46', '1aaa1f8411da8bf17e7a89b1355db54f1a68e17c',  'Tressa', 'Hilll', '2010-11-11', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('43', 'ila.murphy', '43f3283830ed3357caff7fbbba6413edb8e727db',  'Asa', 'Mayert', '2010-11-12', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('44', 'willms.eddie', 'ff820843166ceb4a56b3467fa93737c6b3b9a3ad',  'Marquis', 'Sipes', '2010-11-13', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('45', 'cordelia.okuneva', '05828df4b1a3f2037e37d7819d05f94c66f6c10c',  'Torey', 'Sawayn', '2010-11-14', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('46', 'aleen29', '73c1a988b6d198e210ee015e983d159d4d2aa0c9','Shyann', 'Wolf', '2010-11-15', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('47', 'beahan.lexie', '319e7aebe59da9cf4537aa8b169d49b1d0a656ad',  'Tristin', 'Kshlerin', '2010-11-16', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('48', 'srempel', 'a4d6d4862b9d7520c965ed8d79ca8b4721b55c0f', 'Dexter', 'Romaguera', '2010-11-17', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('49', 'nreynolds', '5132e8cddbf32455f5d5435ad9a49eedce30f887',  'Frida', 'Feil', '2010-11-18', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('50', 'lempi.renner', '946c225b0b5f414b73b960362dd2e058e5e39d9f',  'Aurelio', 'Towne', '2010-11-19', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('51', 'gwintheiser', '530f99a29408de2480d319a2a3c6f03e393cb821',  'Kristian', 'Nienow', '2010-11-20', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('52', 'shaylee53', '9a6e21916fa2b02bf12cb2120c62c1e85963b66f',  'Leland', 'Hamill', '2010-11-21', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('53', 'francesco04', 'a68ee23949026e02e02484b3b6c25d65265e6ff7',  'Blanche', 'Fritsch', '2010-11-22', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('54', 'xmcdermott', 'b511e898455508d4b4c2b4709ba983f58fd7678a',  'Ervin', 'Hudson', '2010-11-23', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('55', 'ustehr', '0553b837a6bc2011ae96f4d112b35a2e0c9f0cf8', 'Humberto', 'Kulas', '2010-11-24', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('56', 'ljast', '05defd7dcec977068b147fb6dc661699e2fd09d2',  'Terrell', 'Schroeder', '2010-11-25', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('57', 'bartell.alexanne', 'f9f56682d7a3a50b569268ff451a5193dd3a6b4c',  'Nakia', 'Schuppe', '2010-11-26', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('58', 'jparisian', 'feab2feae6b9c18c6bf45f8d059998000d1480ed', 'Hermina', 'Reilly', '2010-11-27', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('59', 'iframi', 'e6b5174e677cdf861d76f116f3e999b8ac54d38b', 'Jefferey', 'Ferry', '2010-11-28', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('60', 'talon85', '6a52714cc10da781b25776628634c4258c4e6b99', 'Shana', 'Labadie', '2010-11-29', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('61', 's', '1', 'kelly', 'Ladie', '2008-11-07', 0, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('62', 'hayon55', '1', 'kelly', 'Ladie', '1988-11-07', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('63', 't', '1', 'kelly', 'Ladie', '1988-11-07', 1, 0, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('64', 'a', '1', 'kelly', 'Ladie', '1988-11-07', 0, 1, '2020-04-18 19:40:35');
INSERT INTO Xristes (id_xristi, username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update) VALUES ('65', 'j', '1', 'kelly', 'Ladie', '1988-11-07', 1, 0, '2020-04-18 19:40:35');

-- table Anhkei_SM
-- καθε χρηστης πρεπει να ανηκει σε μια σχολικη μοναδα
-- χωριζουμε ομοιομορφα τους μαθητες και τους εκπαιδευτικους σε σχολικες μοναδες


INSERT INTO `Anhkei_SM`
    (select 1 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 1 and 4 );

INSERT INTO `Anhkei_SM`
    (select 2 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 5 and 8 );

INSERT INTO `Anhkei_SM`
    (select 3 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 9 and 12  );

INSERT INTO `Anhkei_SM`
    (select 4 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 13 and 16 );

INSERT INTO `Anhkei_SM`
    (select 5 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 17 and 20 );

INSERT INTO `Anhkei_SM`
    (select 1 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 20 and 28 );

INSERT INTO `Anhkei_SM`
    (select 2 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 29 and 36 );

INSERT INTO `Anhkei_SM`
    (select 3 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 37 and 44 );

INSERT INTO `Anhkei_SM`
    (select 4 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 45 and 52 );

INSERT INTO `Anhkei_SM`
    (select 5 , id_xristi , '2020-04-18 23:45:00 '
     from Xristes
     where id_xristi between 53 and 65 );



-- table Einai_Xeiristis
-- αντιστοιχος χειρηιστης για καθε σχολικη μοναδα εινια οι 1 , 5 , 9 , 13 , 17


INSERT INTO `Einai_Xeiristis` (`id_sxolikis_monadas`, `id_xristi`, `hm_enarxis`, `hm_lixis`, `last_update`) VALUES ('1', '1', '2022-01-01 03:00:00 ', NULL,  '2022-01-01 03:00:00 ');
INSERT INTO `Einai_Xeiristis` (`id_sxolikis_monadas`, `id_xristi`, `hm_enarxis`, `hm_lixis`, `last_update`) VALUES ('2', '5', '2022-01-01 03:00:00 ', NULL,   '2022-01-01 03:00:00 ');
INSERT INTO `Einai_Xeiristis` (`id_sxolikis_monadas`, `id_xristi`, `hm_enarxis`, `hm_lixis`, `last_update`) VALUES ('3', '9', '2022-01-01 03:00:00 ', NULL,   '2022-01-01 03:00:00 ');
INSERT INTO `Einai_Xeiristis` (`id_sxolikis_monadas`, `id_xristi`, `hm_enarxis`, `hm_lixis`, `last_update`) VALUES ('4', '13', '2022-01-01 03:00:00 ', NULL,  '2022-01-01 03:00:00 ');
INSERT INTO `Einai_Xeiristis` (`id_sxolikis_monadas`, `id_xristi`, `hm_enarxis`, `hm_lixis`, `last_update`) VALUES ('5', '65', '2022-01-01 03:00:00 ', NULL,  '2022-01-01 03:00:00 ');

-- table Daneismoi_Kratiseis

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('1', '1' , '1260116123' , '2022-07-07 14:06:41', null, null, '2022-07-07 14:06:41');


INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('2', '1' , '0133807800' , '2022-05-27 14:46:41', '2022-05-28 14:45:41', '2022-06-01 14:45:41' , '2022-06-01 14:45:41');


INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('3', '1' , '1260116123' , '2022-07-22 14:06:41', '2022-07-27 14:06:41 ', '2022-08-17 14:06:41', '2022-07-07 14:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('4', '1' , '960410912X' , '2022-11-06 14:06:41', '2022-11-09 14:56:41 ', '2022-11-18 14:56:41 ', '2022-11-18 14:56:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('5', '3' , '9603642983' , '2022-01-09 14:06:41', '2022-01-13 14:56:41 ', '2022-01-17 14:56:41 ', '2022-01-17 14:56:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('6', '3' , '9603281417', '2022-02-09 14:06:41', '2022-02-13 14:56:41 ', '2022-02-17 14:56:41 ', '2022-01-17 14:56:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('7', '3' , '9609227201', '2022-03-09 14:06:41', null, null, '2022-01-17 14:56:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('8', '22' , '9609227201', '2022-03-09 14:06:41','2022-03-09 14:26:41', '2022-03-14 14:26:41', '2022-03-14 14:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('9', '23' , '9607089243', '2022-07-09 18:06:41','2022-07-12 18:06:41', '2022-07-21 18:06:41', '2022-03-04 14:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('10', '23' , '9605210231', '2022-09-09 18:06:41',null, null, '2022-03-04 14:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('11', '23' , '9606263347', '2022-03-09 11:06:41','2022-03-14 11:06:41', '2022-03-18 11:06:41', '2022-03-18 11:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('12', '7' , '9606263347', '2022-03-09 11:06:41','2022-03-14 11:06:41', '2022-03-18 11:06:41', '2022-03-18 11:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('13', '7' ,'9600118833', '2022-08-19 18:06:41','2022-08-22 18:06:41', '2022-08-25 18:06:41', '2022-08-25 18:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('14', '7' ,'9606674665', '2022-12-19 18:06:41','2022-12-25 18:06:41', '2023-01-14 18:06:41', '2023-01-14 18:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('15', '30' ,'9607745116', '2022-12-19 18:06:41',null, null, '2022-12-19 18:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('16', '32' ,'0140188223', '2023-02-09 08:06:41','2023-02-13 08:06:41', '2023-02-28 08:06:41','2023-02-28 08:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('17', '32' ,'9600112754' ,'2022-03-29 08:06:41', null, null, '2023-03-19 18:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('18', '31' ,'960512680X' ,'2022-04-29 08:06:41', null, null, '2023-03-19 18:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('19', '31' ,'9604188798' ,'2022-05-05 08:06:41', '2022-05-06 08:06:41', '2022-05-11 08:06:41', '2022-05-11 08:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('20', '31' ,'9607745116' ,'2022-06-05 08:06:41', null, null, '2022-06-05 08:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('21', '32' ,'9607745116' ,'2022-06-05 08:16:41', null, null, '2022-06-05 08:16:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('22', '33' ,'9607745116' ,'2022-06-05 08:26:41', '2022-06-06 08:26:41', '2022-06-25 08:26:41', '2022-06-25 08:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('23', '9' ,'9606263347' ,'2022-07-05 08:26:41', '2022-07-06 08:26:41', '2022-07-25 08:26:41', '2022-07-25 08:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('24','9' ,'9609227201' ,'2022-09-12 08:26:41', '2022-09-14 08:26:41', '2022-09-18 08:26:41', '2022-09-18 08:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('25', '9' ,'9607089243' ,'2022-01-12 08:26:41', '2022-01-14 08:26:41', '2022-01-18 08:26:41', '2022-09-18 08:06:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('26', '9' ,'9606674665' ,'2023-02-12 08:26:41', null, null, '2023-02-12 08:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('27', '39' ,'0133807800' ,'2023-02-12 18:26:41', null, null, '2023-02-12 08:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('28', '39' ,'6185598167','2023-03-12 18:26:41', '2023-03-15 18:26:41', '2023-03-20 18:26:41', '2023-03-20 18:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('29', '39' ,'9600112754','2022-09-12 18:26:41', '2022-09-15 18:26:41', '2022-09-20 18:26:41', '2022-09-20 18:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('30', '42' ,'9600118833','2022-10-12 18:26:41', '2022-10-15 18:26:41', '2022-10-20 18:26:41', '2022-10-20 18:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('31', '42' ,'9600328390','2022-10-20 18:26:41', '2022-10-25 18:26:41', '2022-11-20 18:26:41', '2022-11-20 18:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('32', '42' ,'9600328390','2022-10-20 18:26:41', '2022-10-25 18:26:41', '2022-11-20 18:26:41', '2022-11-20 18:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('33', '44' , '9603250880','2022-04-20 08:26:41', '2022-04-25 08:26:41', '2022-04-29 08:26:41', '2022-04-29 08:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('34', '15' , '9603789151','2022-10-20 08:26:41', '2022-10-25 08:26:41', '2022-10-28 08:26:41', '2022-10-28 08:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('35', '17' , '960410912X','2022-10-20 08:26:41', '2022-10-25 08:26:41', '2022-10-28 08:26:41','2022-10-28 08:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('36', '17' , '9602367725','2022-06-25 08:26:41', null, null, '2022-06-25 08:26:41');

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('37', '55' , '9603250880','2022-11-25 08:26:41', '2022-11-27 08:26:41', '2022-11-29 08:26:41', '2022-11-29 08:26:41' );

INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('38', '59' , '9607243048','2023-04-01 08:26:41', '2023-04-05 08:26:41', '2023-04-11 08:26:41', '2023-04-11 08:26:41' );


INSERT INTO `Daneismoi_Kratiseis`
(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
VALUES
('39', '60' ,'960512680X','2023-04-01 08:26:41', null, null , '2023-04-01 08:26:41' );

--INSERT INTO `Daneismoi_Kratiseis`
--(`id_DK`, `id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
--VALUES
--('40', '60' ,'960512680X','2023-05-01 08:26:41', '2023-05-02 08:26:41', null , '2023-05-02 08:26:41' );



--INSERT INTO `Daneismoi_Kratiseis`
--(`id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
--VALUES
--('59' ,'9609227201','2023-05-15 08:26:41', null, null , '2023-05-15 08:26:41' );

--INSERT INTO `Daneismoi_Kratiseis`
--(`id_xristi`, `isbn`, `hm_kratisis`, `hm_daneismou`, `hm_epistrofis`, `last_update`)
--VALUES
--('59' ,'9609227201','2023-05-15 08:26:41', null, null , '2023-05-15 08:26:41' );


INSERT INTO Daneismoi_Kratiseis (id_xristi, isbn, hm_kratisis, hm_daneismou, hm_epistrofis)
SELECT
    x.id_xristi,
    b.isbn,
    DATE_ADD('2023-04-20 13:24:14', INTERVAL 15 DAY),
    DATE_ADD('2023-04-20 13:24:14', INTERVAL 15 + FLOOR(RAND() * 6) DAY),
    DATE_ADD('2023-04-20 13:24:14', INTERVAL 21 + FLOOR(RAND() * 6) DAY)
FROM
    (SELECT id_xristi FROM Xristes ORDER BY RAND() LIMIT 5) x
    CROSS JOIN (SELECT isbn FROM Biblia ORDER BY RAND() LIMIT 5) b;


INSERT INTO Daneismoi_Kratiseis (id_xristi, isbn, hm_kratisis, hm_daneismou, hm_epistrofis)
SELECT
    x.id_xristi,
    b.isbn,
    DATE_ADD('2023-04-20 13:24:14', INTERVAL 15 DAY),
    DATE_ADD('2023-04-20 13:24:14', INTERVAL 15 + FLOOR(RAND() * 6) DAY),
    DATE_ADD('2023-04-20 13:24:14', INTERVAL 21 + FLOOR(RAND() * 6) DAY)
FROM
    (SELECT id_xristi FROM Xristes ORDER BY RAND() LIMIT 5) x
    CROSS JOIN (SELECT isbn FROM Biblia ORDER BY RAND() LIMIT 5) b;




-- table Aksiologisi


INSERT INTO Aksiologisi (id_xristi, isbn, bathmologia, kritiki, hm_dhmiourgias, hm_egrisis)
VALUES
    (1, '9607243048', 4, 'Good book!', '2023-01-05 10:00:00', '2023-01-10 10:00:00'),
    (12, '1260116123', 5, 'Excellent book!', '2023-02-05 10:00:00', '2023-02-10 10:00:00'),
    (23, '9609227201', 3, 'Average book.', '2023-03-05 10:00:00', '2023-03-10 10:00:00'),
    (14, '9607089243', 2, 'Not so good.', '2023-04-05 10:00:00', '2023-04-10 10:00:00'),
    (25, '9606263347', 1, 'Bad book!', '2023-05-05 10:00:00', '2023-05-10 10:00:00'),
    (18, '9605210231', 3, 'Average book.', '2023-06-05 10:00:00', '2023-06-10 10:00:00'),
    (29, '9600118833', 4, 'Good book!', '2023-07-05 10:00:00', '2023-07-10 10:00:00'),
    (32, '9606263347', 2, 'Not so good.', '2023-08-05 10:00:00', '2023-08-10 10:00:00'),
    (49, '9603642983', 5, 'Excellent book!', '2023-09-05 10:00:00', '2023-09-10 10:00:00'),
    (52, '9607745116', 3, 'Average book.', '2023-10-05 10:00:00', '2023-10-10 10:00:00'),
    (10, '9606674665', 2, 'Not so good.', '2023-11-05 10:00:00', '2023-11-10 10:00:00'),
    (52, '9606674665', 1, 'Bad book!', '2023-12-05 10:00:00', '2023-12-10 10:00:00'),
    (39, '9603281417', 4, 'Good book!', '2024-01-05 10:00:00', '2024-01-10 10:00:00'),
    (42, '9607243048', 3, 'Average book.', '2024-02-05 10:00:00', '2024-02-10 10:00:00'),
    (57, '9607243048', 5, 'Excellent book!', '2024-03-05 10:00:00', '2024-03-10 10:00:00'),
    (46, '9607243048', 4, 'Good book!', '2023-01-05 10:00:00', '2023-01-10 10:00:00'),
    (32, '9603643440', 5, 'Excellent book!', '2023-02-05 10:00:00', '2023-02-10 10:00:00'),
    (43, '9603642983', 3, 'Average book.', '2023-03-05 10:00:00', '2023-03-10 10:00:00'),
    (44, '9607089243', 2, 'Not so good.', '2023-04-05 10:00:00', '2023-04-10 10:00:00'),
    (25, '9600328390', 1, 'Bad book!', '2023-05-05 10:00:00', '2023-05-10 10:00:00'),
    (38, '1260116123', 3, 'Average book.', '2023-06-05 10:00:00', '2023-06-10 10:00:00'),
    (49, '9603280860', 4, 'Good book!', '2023-07-05 10:00:00', '2023-07-10 10:00:00'),
    (52, '9605210231', 2, 'Not so good.', '2023-08-05 10:00:00', '2023-08-10 10:00:00'),
    (59, '9609227201', 5, 'Excellent book!', '2023-09-05 10:00:00', '2023-09-10 10:00:00'),
    (32, '9606263347', 3, 'Average book.', '2023-10-05 10:00:00', '2023-10-10 10:00:00'),
    (40, '9603281417', 2, 'Not so good.', '2023-11-05 10:00:00', '2023-11-10 10:00:00'),
    (22, '9600118833', 1, 'Bad book!', '2023-12-05 10:00:00', '2023-12-10 10:00:00'),
    (9, '9607089243', 4, 'Good book!', '2024-01-05 10:00:00', '2024-01-10 10:00:00'),
    (4, '1260116123', 3, 'Average book.', '2024-02-05 10:00:00', '2024-02-10 10:00:00'),
    (7, '9609227201', 5, 'Excellent book!', '2024-03-05 10:00:00', '2024-03-10 10:00:00');




-- table Aksiologisi


INSERT INTO `Aksiologisi`
(`isbn`, `bathmologia`, `kritiki`, hm_dhmiourgias, hm_egrisis, `last_update`)
VALUES
('9607243048', '4', 'Tears cried Alice again, for really I\m quite tired and out of the trees as well to introduce some other subject of conversation.', current_timestamp, NULL, current_timestamp );
