
DELIMITER //




CREATE PROCEDURE Aksiologisi_Creation (
  IN n_id_xristi INT,
  IN n_isbn VARCHAR(40),
  IN n_bathmologia DECIMAL(2, 1),
  IN n_kritiki TEXT
)
BEGIN
  DECLARE id_aksiologisis INT;

  IF (n_bathmologia > 5 OR n_bathmologia < 1) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Please select a rating between 1 and 5';
  END IF;

  INSERT INTO Aksiologisi (id_xristi, isbn, bathmologia, kritiki, hm_dhmiourgias, hm_egrisis, last_update)
  VALUES (n_id_xristi, n_isbn, n_bathmologia, n_kritiki, CURRENT_TIMESTAMP, NULL, CURRENT_TIMESTAMP);
END //




CREATE PROCEDURE Xristis_Creation (
IN n_username varchar(40),
IN n_password varchar(40),
IN n_onoma varchar(40),
IN n_epwnumo varchar(40),
IN n_hm_gennisis date,
IN n_stud_prof boolean,
IN n_is_admin boolean,
IN n_id_sxolikis_monadas int
)
BEGIN
DECLARE id_xristi int;

INSERT INTO Xristes (username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, last_update)
VALUES (n_username, n_password, n_onoma, n_epwnumo, n_hm_gennisis, n_stud_prof, n_is_admin, current_timestamp());

SET id_xristi = LAST_INSERT_ID();

IF NOT EXISTS (
SELECT id_sxolikis_monadas
FROM Sxoliki_Monada
WHERE id_sxolikis_monadas = n_id_sxolikis_monadas
) THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid id_sxolikis_monadas';
END IF;

INSERT INTO Anhkei_SM (id_sxolikis_monadas, id_xristi, last_update)
VALUES (n_id_sxolikis_monadas, id_xristi, current_timestamp());
END //


CREATE PROCEDURE Stoixeia_Update (
IN id_xristi int,
IN n_username varchar(50),
IN n_onoma varchar(45),
IN n_epwnumo varchar(45),
IN n_hm_gennhshs date
)
BEGIN
IF NOT EXISTS (
SELECT * FROM Xristes
WHERE id_xristi = id_xristi
)
THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The specified user (id_xristi) does not exist';
END IF;

IF NOT EXISTS (
SELECT * FROM Xristes
WHERE id_xristi = id_xristi AND stud_prof = 1
) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Students have no right to edit their personal data';
END IF;

IF n_username IS NOT NULL THEN
UPDATE Xristes
SET username = n_username
WHERE id_xristi = id_xristi;
END IF;

IF n_onoma IS NOT NULL THEN
UPDATE Xristes
SET onoma = n_onoma
WHERE id_xristi = id_xristi;
END IF;

IF n_epwnumo IS NOT NULL THEN
UPDATE Xristes
SET epwnumo = n_epwnumo
WHERE id_xristi = id_xristi;
END IF;

IF n_hm_gennhshs IS NOT NULL THEN
UPDATE Xristes
SET hm_gennhshs = n_hm_gennhshs
WHERE id_xristi = id_xristi;
END IF;
END //



CREATE PROCEDURE Biblio_Creation (
    IN n_titlos varchar(40),
    IN n_ekdoths varchar(40),
    IN n_glwssa varchar(40),
    IN n_selides int,
    IN n_perilipsi text,
    IN n_onoma_suggrafea varchar(50),
    IN n_onoma_kathgorias varchar(50)
)
BEGIN
    DECLARE id_k INT;
    DECLARE id_s INT;
    DECLARE isbn char(10);


    SET isbn = COALESCE((SELECT MAX(isbn) FROM Biblia), 0) + 1;

    INSERT INTO Biblia
    (isbn, titlos, ekdoths, glwssa, selides, perilipsi, eikona, last_update)
    VALUES
    (isbn, n_titlos, n_ekdoths, n_glwssa, n_selides, n_perilipsi, NULL, CURRENT_TIMESTAMP());


    IF EXISTS (
        SELECT id_kathgorias
        FROM Kathgories
        WHERE onoma_kathgorias = n_onoma_kathgorias
    ) THEN

        SELECT id_kathgorias INTO id_k
        FROM Kathgories
        WHERE onoma_kathgorias = n_onoma_kathgorias;
    ELSE

        INSERT INTO Kathgories (onoma_kathgorias, last_update)
        VALUES (n_onoma_kathgorias, CURRENT_TIMESTAMP());

        SET id_k = LAST_INSERT_ID();
    END IF;


    INSERT INTO Anhkei (id_kathgorias, isbn, last_update)
    VALUES (id_k, isbn, CURRENT_TIMESTAMP());


    IF EXISTS (
        SELECT id_suggrafea
        FROM Suggrafeis
        WHERE onoma_suggrafea = n_onoma_suggrafea
    ) THEN

        SELECT id_suggrafea INTO id_s
        FROM Suggrafeis
        WHERE onoma_suggrafea = n_onoma_suggrafea;
    ELSE

        INSERT INTO Suggrafeis (onoma_suggrafea, last_update)
        VALUES (n_onoma_suggrafea, CURRENT_TIMESTAMP());

        SET id_s = LAST_INSERT_ID();
    END IF;


    INSERT INTO Exei_grapsei (id_suggrafea, isbn, last_update)
    VALUES (id_s, isbn, CURRENT_TIMESTAMP());

END //




CREATE PROCEDURE Biblio_Update (
    IN n_titlos varchar(40),
    IN n_ekdoths varchar(40),
    IN n_glwssa varchar(40),
    IN n_selides int,
    IN n_perilipsi text,
    IN n_ISBN int
)
BEGIN
    IF n_titlos IS NOT NULL THEN
        UPDATE Biblia
        SET titlos = n_titlos
        WHERE ISBN = n_ISBN;
    END IF;

    IF n_ekdoths IS NOT NULL THEN
        UPDATE Biblia
        SET ekdoths = n_ekdoths
        WHERE ISBN = n_ISBN;
    END IF;

    IF n_glwssa IS NOT NULL THEN
        UPDATE Biblia
        SET glwssa = n_glwssa
        WHERE ISBN = n_ISBN;
    END IF;

    IF n_selides IS NOT NULL THEN
        UPDATE Biblia
        SET selides = n_selides
        WHERE ISBN = n_ISBN;
    END IF;

    IF n_perilipsi IS NOT NULL THEN
        UPDATE Biblia
        SET perilipsi = n_perilipsi
        WHERE ISBN = n_ISBN;
    END IF;
END //




CREATE PROCEDURE Sxoliki_Monada_Creation (
  IN n_onomasia_sm varchar(45),
  IN n_TK decimal(5,0),
  IN n_Polh varchar(45),
  IN n_Thlefwno decimal(10,0),
  IN n_email varchar(45),
  IN n_onoma_dieuthunti varchar(45)
)
BEGIN

  INSERT INTO Sxoliki_Monada (onomasia_sm, TK, Polh, Thlefwno, email, onoma_dieuthunti, last_update)
  VALUES (n_onomasia_sm, n_TK, n_Polh, n_Thlefwno, n_email, n_onoma_dieuthunti, CURRENT_TIMESTAMP());

END //







CREATE PROCEDURE Sxoliki_Monada_Update (
  IN n_onomasia_sm VARCHAR(45),
  IN n_TK DECIMAL(5, 0),
  IN n_Polh VARCHAR(45),
  IN n_Thlefwno DECIMAL(10, 0),
  IN n_email VARCHAR(45),
  IN n_onoma_dieuthunti VARCHAR(45),
  IN n_id_sxolikis_monadas INT
)
BEGIN
  IF n_onomasia_sm IS NOT NULL THEN
    UPDATE Sxoliki_Monada
    SET onomasia_sm = n_onomasia_sm
    WHERE id_sxolikis_monadas = n_id_sxolikis_monadas;
  END IF;

  IF n_TK IS NOT NULL THEN
    UPDATE Sxoliki_Monada
    SET TK = n_TK
    WHERE id_sxolikis_monadas = n_id_sxolikis_monadas;
  END IF;

  IF n_Polh IS NOT NULL THEN
    UPDATE Sxoliki_Monada
    SET Polh = n_Polh
    WHERE id_sxolikis_monadas = n_id_sxolikis_monadas;
  END IF;

  IF n_Thlefwno IS NOT NULL THEN
    UPDATE Sxoliki_Monada
    SET Thlefwno = n_Thlefwno
    WHERE id_sxolikis_monadas = n_id_sxolikis_monadas;
  END IF;

  IF n_email IS NOT NULL THEN
    UPDATE Sxoliki_Monada
    SET email = n_email
    WHERE id_sxolikis_monadas = n_id_sxolikis_monadas;
  END IF;

  IF n_onoma_dieuthunti IS NOT NULL THEN
    UPDATE Sxoliki_Monada
    SET onoma_dieuthunti = n_onoma_dieuthunti
    WHERE id_sxolikis_monadas = n_id_sxolikis_monadas;
  END IF;
END //


DELIMITER ;
