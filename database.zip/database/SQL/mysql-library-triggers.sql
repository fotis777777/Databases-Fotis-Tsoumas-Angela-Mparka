-- ΓΙΑ ΝΑ ΕΓΚΡΙΘΕΙ Η ΚΡΑΤΗΣΗ ΕΝΟΣ ΒΙΒΛΙΟΥ ΑΠΟ ΕΝΑΝ ΧΡΗΣΤΗ

--                      #######    1    #######
-- θΕΤΟΥΜΕ ΤΟΝ ΠΕΡΙΟΣΜΟ : ΕΑΝ ΕΝΑΣ ΧΡΗΣΤΗΣ ΔΕΝ ΕΧΕΙ ΚΑΝΕΙ ΕΠΙΣΤΡΟΦΗ ΚΑΠΟΙΟΥ ΒΙΒΛΙΟΥ  ΧΑΝΕΙ ΤΟ
-- ΔΙΚΑΙΩΜΑ ΚΡΑΤΗΣΗΣ ΚΑΙ ΔΑΝΕΙΣΜΟΥ ΒΙΒΛΙΟΥ
--
-- ΣΥΝΑΡΤΗΣΗ -> ΠΛΗΘΟΣ ΒΙΒΛΙΩΝ ΠΟΥ ΔΕΝ ΕΧΟΥΝ ΕΠΙΣΤΡΑΦΕΙ ΠΟΤΕ ΓΙΑ ΣΥΓΚΕΚΡΙΜΕΝΟ ΧΡΗΣΤΗ 
DELIMITER $$

CREATE PROCEDURE epistrofes (IN new_id_xristi INT , OUT E_Count INT)
READS SQL DATA
BEGIN 
      select count(s.id_DK) into E_Count
      from (
            select id_DK ,  hm_daneismou , hm_epistrofis
            from Daneismoi_Kratiseis 
            where id_xristi = new_id_xristi and (select DATE_SUB(now(), INTERVAL 7 DAY)) > hm_daneismou and hm_epistrofis is null 
            )s ;
END $$

DELIMITER ;

-- call epistrofes('1', @e);
-- select @e;

--                      #######    2    #######
-- θΕΤΟΥΜΕ ΤΟΝ ΠΕΡΙΟΣΜΟ : ΕΑΝ ΕΝΑΣ ΧΡΗΣΤΗΣ ΕΧΕΙ ΚΑΘΥΣΤΕΡΗΣΕΙ ΤΗΝ ΕΠΙΣΤΡΟΦΗ ΒΙΒΛΙΟΥ ΤΟΥΛΑΧΙΣΤΟΝ 4 ΦΟΡΕΣ ΧΑΝΕΙ ΤΟ
-- ΔΙΚΑΙΩΜΑ ΚΡΑΤΗΣΗΣ ΚΑΙ ΔΑΝΕΙΣΜΟΥ ΒΙΒΛΙΟΥ

-- ΣΥΝΑΡΤΗΣΗ -> ΠΛΗΘΟΣ ΚΑΘΥΣΤΕΡΗΜΕΝΩΝ ΕΠΙΣΤΟΦΩΝ ΓΙΑ ΣΥΓΚΕΚΡΙΜΕΝΟ ΧΡΗΣΤΗ 

DELIMITER $$

CREATE PROCEDURE kathisterimenes_epistrofes (IN new_id_xristi INT , OUT E_Count INT)
READS SQL DATA
BEGIN 
      select count(s.id_DK) into E_Count
      from (
            (select id_DK ,  hm_daneismou , hm_epistrofis , new_id_xristi
            from Daneismoi_Kratiseis 
            where id_xristi = new_id_xristi and hm_epistrofis is not null and (select DATE_SUB(hm_epistrofis,INTERVAL 7 DAY)) > hm_daneismou )
          )s ;
END $$

DELIMITER ;

-- call kathisterimenes_epistrofes('1', @e);
--  select @e;


--                      #######    3    #######
-- ΓΙΑ ΤΙΣ ΤΕΛΕΥΤΑΙΕΣ 7 ΜΕΡΕΣ ΘΑ ΠΡΕΠΕΙ ΝΑ ΜΗΝ ΥΠΑΡΧΟΥΝ 2 ΣΥΝΟΛΙΚΑ ΚΡΑΤΗΣΕΙΣ-ΔΑΝΕΙΣΜΟΙ
-- 

-- ΣΥΝΑΡΤΗΣΗ -> ΠΛΗΘΟΣ ΔΑΝΕΙΣΜΩΝ-ΚΡΑΤΗΣΕΩΝ ΓΙΑ ΣΥΓΚΕΚΡΙΜΕΝΟ ΧΡΗΣΤΗ ΓΙΑ ΤΙΣ ΤΕΛΕΥΤΑΙΕΣ 7 ΗΜΕΡΕΣ
-- ΠΡΟΣΟΧΗ - ΤΟ ΝΟΗΜΑ ΕΙΝΑΙ ΝΑ ΜΗΝ ΕΧΕΙ ΔΕΣΜΕΥΣΗ 2 ΒΙΒΛΙΑ ΣΤΟ ΙΔΙΟ ΔΙΑΣΤΗΜΑ
-- ΥΠΑΡΧΕΙ ΠΕΡΙΠΤΩΣΗ ΝΑ ΕΧΕΙ ΚΑΝΕΙ ΕΝΑΝ ΔΕΝΕΙΣΜΟ ΜΕΣΑ ΣΤΗΝ ΕΒΔΟΜΑΔΑ ΚΑΙ ΝΑ ΕΠΕΣΤΡΕΨΕ ΤΟ ΒΙΒΛΙΟ ΤΗΝ ΕΠΟΜΕΝΗ ΜΕΡΑ
-- ΑΥΤΟΣ ΔΕΝ ΜΠΟΡΕΙ ΝΑ ΜΕΤΡΗΘΕΙ ΣΤΟΝ ΠΕΡΙΟΣΜΟ ΤΩΝ 2 ΒΙΒΛΙΩΝ 

DELIMITER $$

CREATE PROCEDURE pl_KD (IN new_id_xristi INT , OUT DK_Count INT )
READS SQL DATA
BEGIN 
      select count(s.id_DK) into DK_Count
      from (
            (select id_DK , hm_kratisis , hm_daneismou
            from Daneismoi_Kratiseis 
            where id_xristi = new_id_xristi and (select DATE_SUB(now(),INTERVAL 7 DAY)) <= hm_kratisis ) 
            union
            (select id_DK , hm_kratisis , hm_daneismou
            from Daneismoi_Kratiseis 
            where id_xristi = new_id_xristi and (select DATE_SUB(now(), INTERVAL 7 DAY)) <= hm_daneismou and hm_epistrofis is null ) 
          )s ;

END $$

DELIMITER ;

-- call pl_KD('1', @a );

-- select @a;

--                      #######    4    #######
-- ΕΛΕΓΧΟΣ ΔΙΑΘΕΣΙΜΟΥ ΒΙΒΛΙΟΥ ΓΙΑ ΚΡΑΤΗΣΗ ( Ή ΔΑΝΕΙΣΜΟ )
-- 
-- ΣΥΝΑΡΤΗΣΗ -> ΠΛΗΘΟΣ ΔΙΑΘΕΣΙΜΩΝ ΑΝΤΙΤΥΠΩΝ ΓΙΑ ΣΥΓΚΕΚΡΙΜΕΝΟ ΒΙΒΛΙΟ ΤΟ ΟΠΟΙΟ ΑΝΗΚΕΙ ΣΤΗ ΣΧΟΛΙΚΗ ΜΟΝΑΔΑ ΤΟΥ ΣΥΓΚΕΚΡΙΜΕΝΟΥ ΧΡΗΣΤΗ 

-- ΟΣΟΙ ΧΕΙΡΙΣΤΕΣ ΕΙΝΑΙ ΕΚΠΑΙΔΕΥΤΙΚΟΙ  ΕΧΟΥΝ ΤΟ ΔΙΚΑΙΩΜΑ ΔΑΝΕΙΣΜΟΥ , ΔΙΟΤΙ ΘΑ ΑΝΗΚΟΥΝ ΣΕ ΜΙΑ ΣΧΟΛΙΚΗ ΜΟΝΑΔΑ . ΑΥΤΟ ΑΝΑΦΕΡΕΤΑΙ ΔΙΟΤΙ ΣΤΗΝ ΠΑΡΑΚΑΤΩ ΣΥΝΑΣΡΤΗΣΗ 
-- ΘΑ ΕΝΤΟΠΙΖΟΥΜΕ ΤΗΝ ΣΧΟΛΙΚΗ ΜΟΝΑΔΑ ΠΟΥ ΑΝΗΚΕΙ Ο ΧΡΗΣΤΗΣ ΓΙΑ ΝΑ ΒΡΙΣΚΟΥΜΕ ΤΑ ΔΙΑΘΕΣΙΜΑ ΒΙΒΛΙΑ ΠΟΥ ΥΠΑΡΧΟΥΝ ΓΙΑ ΑΥΤΗΝ .

DELIMITER $$ 

CREATE PROCEDURE pl_bibliwn(IN new_id_xristi INT ,IN new_isbn VARCHAR(40) , OUT b_Count INT , OUT c_Count INT)
READS SQL DATA
BEGIN 
      select d.ar_diathesimwn into b_Count 
      from anhkei_sm a
      inner join diathesima_antitupa d 
      on a.id_sxolikis_monadas = d.id_sxolikis_monadas
      where id_xristi = new_id_xristi and isbn = new_isbn  ;  

      select d.ar_daneismenwn into c_Count 
      from anhkei_sm a
      inner join diathesima_antitupa d 
      on a.id_sxolikis_monadas = d.id_sxolikis_monadas
      where id_xristi = new_id_xristi and isbn = new_isbn  ;  
END $$
DELIMITER ;

-- call pl_bibliwn('59','9609227201', @a , @b );

-- select @a;
-- select @b;

-- φτιαχνω ενα procedure το οποιο θελω να μου δινει την πρωτη υπάρχουσα κρατηση σε αναμονη ΓΙΑ ΣΥΓΚΕΚΡΙΜΕΝΟ ΒΙΒΛΙΟ ΤΗΣ ΣΧΟΛΙΚΗΣ ΜΟΝΑΔΑΣ ΤΟΥ !!!!!!
-- προσοχη = το  new_id_xristi αναφερεται στον χρηστη που επεστρεψε το βιβλιο
DELIMITER $$

CREATE PROCEDURE anamonh (IN new_id_xristi INT ,IN new_isbn VARCHAR(40) ,  OUT id_prwth_anamonh int)
READS SQL DATA
BEGIN 
      select dk.id_DK into id_prwth_anamonh
      FROM daneismoi_kratiseis dk
      INNER JOIN anhkei_sm sm ON dk.id_xristi=sm.id_xristi
      WHERE (select DATE_SUB(now(),INTERVAL 7 DAY)) <= dk.hm_kratisis 
            AND anamonh='1' 
            AND dk.isbn = new_isbn 
            AND  sm.id_sxolikis_monadas = (select id_sxolikis_monadas
                                           from anhkei_sm
                                           where id_xristi=new_id_xristi ) 
      ORDER BY dk.hm_kratisis
      LIMIT 1;

END $$
DELIMITER ;

-- call anamonh('60', @a);

-- select @a; 


-- INSERT στον πινακα Daneismoi_Kratiseis γινεται μονο οταν γινεται απευθειας κρατηση ή απευθειας δανεισμο
-- ΟΛΑ ΤΑ ΥΠΟΛΟΙΠΑ ειναι UPDATE πανω σε αυτα που ηδη εχουν καταχωρηθει



--ΓΕΝΙΚΟΙ ΠΕΡΙΟΡΙΣΜΟΙ

DELIMITER ;;
CREATE TRIGGER `egrish_krathshs_h_daneismoy_xwris_krathsh` BEFORE INSERT ON `Daneismoi_Kratiseis` FOR EACH ROW
BEGIN 
--    με αυτον τον περιορισμο δεν εχω προβλημα οταν εισαγω πληρες tuple, απλα δεν θα γινουν οι παρακατω ελεγχοι
--    οσα ικανοποιουν την παρακατω εισαγωγη αυτα θα περασουν απο ελεγχο
      IF ( new.hm_kratisis is not null AND new.hm_daneismou is null) or (new.hm_kratisis is null AND new.hm_daneismou is not null)
             THEN
                  IF new.id_xristi in ( select * from BANNED_USER_IDS)
                  THEN 
                    SIGNAL SQLSTATE '45000'
                      SET MESSAGE_TEXT = 'EISAI STHN LISTA APOKLEISMOU';
                  END IF;

                  call epistrofes(new.id_xristi, @e);
                  IF (select @e) > 0
                  THEN 
                    SIGNAL SQLSTATE '45000'
                      SET MESSAGE_TEXT = 'BIBLIA XVRIS EPISTROFH.';
                  END IF;

                  call kathisterimenes_epistrofes(new.id_xristi, @ep);
                  IF (select @ep) > 3
                  THEN 
                    SIGNAL SQLSTATE '45000'
                      SET MESSAGE_TEXT = 'KATHISTERIMERES EPISTROFES.';
                  END IF;
      
                  call pl_KD(new.id_xristi, @a);
                  IF (SELECT stud_prof FROM Xristes WHERE id_xristi = new.id_xristi) = '0' 
                  THEN 
                     IF (SELECT @a) >= 2
                     THEN 
                        SIGNAL SQLSTATE '45000'
                         SET MESSAGE_TEXT = 'YPARXOYN HDH DYO KRATHSEIS-DANEISMOI';
                     END IF;
                  ELSE
                     IF (SELECT @a) >= 1 THEN 
                       SIGNAL SQLSTATE '45000'
                         SET MESSAGE_TEXT = 'YPARXEI HDH MIA KRATHSH-DANEISMOS';
                     END IF;
                  END IF;
            

                  IF (select @ab) = 0 and  (select @bc) = 0  
                  THEN 
                    SIGNAL SQLSTATE '45000'
                      SET MESSAGE_TEXT = 'DEN YPARXEI TO SYGKEKRIMENO BIBLIO';
                  END IF;


                  IF new.isbn = ((select isbn 
                                 from Daneismoi_Kratiseis 
                                 where id_xristi = new.id_xristi and (select DATE_SUB(now(),INTERVAL 7 DAY)) <= hm_kratisis ) 
                                 union
                                 (select isbn
                                 from Daneismoi_Kratiseis 
                                 where id_xristi = new.id_xristi and (select DATE_SUB(now(), INTERVAL 7 DAY)) <= hm_daneismou and hm_epistrofis is null ) )
                  THEN 
                    SIGNAL SQLSTATE '45000'
                      SET MESSAGE_TEXT = 'EXEI DESMEYTEI HDH MIA FORA TO SYGKEKRIMRNO BIBLIO';
                  END IF;
      END IF;
END;;


CREATE TRIGGER `krathsh_bibliou_xwris_diathesima_biblia` BEFORE INSERT ON `Daneismoi_Kratiseis` FOR EACH ROW
BEGIN 
     CALL pl_bibliwn(new.id_xristi, new.isbn, @ab, @bc);
     IF new.hm_kratisis IS NULL AND new.hm_daneismou IS NOT NULL THEN
            IF (SELECT @ab) = 0 THEN
                  SIGNAL SQLSTATE '45000'
                  SET MESSAGE_TEXT = 'DEN YPARXOYN DIATHESIMA BIBLIA';
            END IF;
     END IF;

     IF new.hm_kratisis IS NOT NULL AND new.hm_daneismou IS NULL THEN
            IF (SELECT @ab) = 0 THEN
                  SET new.anamonh='1';
            END IF;
     END IF;

END;;

-- επισης θα ειναι πολυ καλο ο χρηστης να εχει 2 κουμπια που το εαν θα του δειχνει 
-- τις ενεργες κρατησεις-δανεισμους
-- και το αλλο να δειχνει τις ενεργες κρατησεις σε αναμονη


CREATE TRIGGER `lathos_update` BEFORE UPDATE ON `Daneismoi_Kratiseis` FOR EACH ROW
BEGIN 
      -- σε καθε περιπτωση η ημερομηνια κρατησης πρεπει να παραμεινει σταθερη 
      IF old.hm_kratisis=!new.hm_kratisis and old.anamonh='0'
      THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'H KRATHSH DEN ALLAZEI';
      END IF;

      IF old.hm_daneismou is not null AND old.hm_daneismou =! new.hm_daneismou
      THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'H HMEROMHNIA DANEISMOY DEN ALLAZEI';
      END IF;

      IF new.hm_daneismou is null AND new.hm_epistrofis is not null 
      THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'DEN YPARXEI DANEISMOS BIBLIOU';
      END IF;
END;;

-- ΕΦΟΣΟΝ ΙΚΑΝΟΠΟΙΟΥΝΤΑΙ ΟΛΑ ΤΑ ΠΑΡΑΠΑΝΩ
-- ΑΚΟΛΟΥΘΕΙ ΜΕΙΩΣΗ ΤΩΝ ΔΙΑΘΕΣΙΜΩΝ ΑΝΤΙΤΥΠΩΝ

--βαζω αυτα τα if παρακατω για να μην εχω προβλημα με τα μαζεμενα insert που κανουμε
--διοτι σε ενα ολοκληρωμενο tuple θα γινει μειωση των διαθεσιμων , αλλα ενημερωση εχει οριστει να γινεται με το update οπως
--αναμενεται να συμβαινει πραγματικα

CREATE TRIGGER `meiwsh_diathesimwn` AFTER INSERT ON `Daneismoi_Kratiseis` FOR EACH ROW BEGIN
      
      IF ( new.hm_kratisis is not null AND new.hm_daneismou is null and new.anamonh='0') or (new.hm_kratisis is null AND new.hm_daneismou is not null AND new.hm_epistrofis is null and new.anamonh='0')
      THEN
            UPDATE diathesima_antitupa 
            SET ar_diathesimwn = ar_diathesimwn - 1
            WHERE isbn = new.isbn and id_sxolikis_monadas in ( select id_sxolikis_monadas
                                                               from anhkei_sm
                                                               where id_xristi = new.id_xristi) ;
      END IF;  
END;;


CREATE TRIGGER `aujhsh_daneismenwn` AFTER INSERT ON `Daneismoi_Kratiseis` FOR EACH ROW BEGIN

      IF ( new.hm_kratisis is not null AND new.hm_daneismou is null and new.anamonh='0') or (new.hm_kratisis is null AND new.hm_daneismou is not null AND new.hm_epistrofis is null and new.anamonh='0')
      THEN
            UPDATE diathesima_antitupa 
            SET ar_daneismenwn = ar_daneismenwn + 1
            WHERE isbn = new.isbn and id_sxolikis_monadas in ( select id_sxolikis_monadas
                                                               from anhkei_sm
                                                               where id_xristi = new.id_xristi) ;
      END IF; 
END;;





-- UPDATE γινεται οταν η κρατηση γινεται δανεισμος                       => δεν επηρεαζονται τα διαθεσιμα
--                     ο δανεισμος γινεται επιστροφη                     => ενημερωνουμε κατα 1 
--                     η κρατηση σε αναμονη γινεται ενεργη για δανεισμο  => απο την επιστροφή έχει γίνει το +1 , άρα εδώ πρέπει να γίνει το -1
--                              διοτι υπαρχει βιβλιο                       


CREATE TRIGGER `enhmerwsh_diathesimwn` AFTER UPDATE ON `Daneismoi_Kratiseis` FOR EACH ROW
BEGIN
      IF (old.hm_daneismou is not null AND new.hm_epistrofis is not null and  old.anamonh='0' ) 
      THEN 
                  UPDATE diathesima_antitupa
                  SET ar_diathesimwn = ar_diathesimwn + 1 
                  WHERE isbn = old.isbn and id_sxolikis_monadas in ( select id_sxolikis_monadas
                                                                     from anhkei_sm
                                                                     where id_xristi = old.id_xristi) ;
 
      END IF; 

      IF (old.anamonh='1'  AND new.anamonh='0' and new.hm_kratisis is not null and new.hm_daneismou is null ) 
      THEN 
                  UPDATE diathesima_antitupa
                  SET ar_diathesimwn = ar_diathesimwn - 1 
                  WHERE isbn = old.isbn and id_sxolikis_monadas in ( select id_sxolikis_monadas
                                                                     from anhkei_sm
                                                                     where id_xristi = old.id_xristi) ;
 
      END IF;  

END;;

CREATE TRIGGER `enhmerwsh_daneismenwn` AFTER UPDATE ON `Daneismoi_Kratiseis` FOR EACH ROW 
BEGIN
       IF (old.hm_daneismou is not null AND new.hm_epistrofis is not null and  old.anamonh='0' ) 
       THEN
            UPDATE diathesima_antitupa
            SET ar_daneismenwn = ar_daneismenwn - 1 
            WHERE isbn = old.isbn and id_sxolikis_monadas in ( select id_sxolikis_monadas
                                                               from anhkei_sm
                                                               where id_xristi = old.id_xristi) ;
      END IF; 

      IF (old.anamonh='1'  AND new.anamonh='0' and new.hm_kratisis is not null and new.hm_daneismou is null ) 
      THEN 
            UPDATE diathesima_antitupa
            SET ar_daneismenwn = ar_daneismenwn + 1 
            WHERE isbn = old.isbn and id_sxolikis_monadas in ( select id_sxolikis_monadas
                                                               from anhkei_sm
                                                               where id_xristi = old.id_xristi) ;
      END IF;     

END;;


--IF old.anamonh='1' - ΔΕΝ ΚΑΝΩ ΤΙΠΟΤΑ

CREATE TRIGGER `enhmerwsh_diathesimvn_2` AFTER DELETE ON `Daneismoi_Kratiseis` FOR EACH ROW 
BEGIN
    IF old.hm_kratisis IS NOT NULL
        AND old.hm_daneismou IS NULL
        AND old.hm_epistrofis IS NULL
        AND old.anamonh = '0'
    THEN
        UPDATE diathesima_antitupa
        SET ar_diathesimwn = ar_diathesimwn + 1 
        WHERE isbn = old.isbn
            AND id_sxolikis_monadas IN (
                SELECT id_sxolikis_monadas
                FROM anhkei_sm
                WHERE id_xristi = old.id_xristi
            );  
    END IF;       
END;



CREATE TRIGGER `enhmerwsh_daneismenwn_2` AFTER DELETE ON `Daneismoi_Kratiseis` FOR EACH ROW BEGIN

    IF  old.hm_kratisis is not null and old.hm_daneismou is null and old.hm_epistrofis is null and old.anamonh='0' 
            THEN
                  UPDATE diathesima_antitupa
                  SET ar_daneismenwn = ar_daneismenwn - 1 
                  WHERE isbn = old.isbn and id_sxolikis_monadas in ( select id_sxolikis_monadas
                                                                     from anhkei_sm
                                                                     where id_xristi = old.id_xristi) ;
        
     END IF;
END;;


DELIMITER ;



-- επισης ΠΡΟΣΟΧΗ δεν θα εισαγουμε δεδομενα με βιβλια που δεν εχουν επιστραφει ποτε, γιατι δεν θα εχει
-- δουλεψει σωστα τα trigger με την μειωση διαθεσιμων - αυξηση δανεισμενων ( αυτα ενημερωνονται με συγκεκριμενες ενεργειες που γινονται)

-- ΔΙΑΦΟΡΕΤΙΚΑ- ΤΡΟΠΟΠΟΙΟΥΜΕ ΟΛΕΣ ΤΟΥΣ ΔΑΝΕΙΣΜΟΥΣ ΚΡΑΤΗΣΕΙΣ  ωστε να γινεται πρωτα κρατηση ή δανεισμος και οι υπολοιπες πληροφοριες να γινονται με UPDATE
-- ετσι ολα θα δουλεψουν με την φυσικη τους ροη !


