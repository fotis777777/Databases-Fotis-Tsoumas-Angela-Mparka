import tkinter as tk
import mysql.connector


from config import ID
from config import id_sm



conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()



def execute_procedure_stoixeia_update():
    n_username = entry_username.get()
    n_onoma = entry_onoma.get()
    n_epwnumo = entry_epwnumo.get()
    n_hm_gennhshs = entry_hm_gennhshs.get()

    try:
        cursor.callproc('Stoixeia_Update', (ID, n_username, n_onoma, n_epwnumo, n_hm_gennhshs))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)


window = tk.Tk()
window.title("Execute SQL Procedure")


label_username = tk.Label(window, text="Username:")
label_username.pack()
entry_username = tk.Entry(window)
entry_username.pack()

label_onoma = tk.Label(window, text="Onoma:")
label_onoma.pack()
entry_onoma = tk.Entry(window)
entry_onoma.pack()

label_epwnumo = tk.Label(window, text="Epwnumo:")
label_epwnumo.pack()
entry_epwnumo = tk.Entry(window)
entry_epwnumo.pack()

label_hm_gennhshs = tk.Label(window, text="Hm Gennisis (YYYY-MM-DD):")
label_hm_gennhshs.pack()
entry_hm_gennhshs = tk.Entry(window)
entry_hm_gennhshs.pack()


def close_connection():
    cursor.close()
    conn.close()
    print("Database connection closed.")


button_execute = tk.Button(window, text="Execute Procedure", command=execute_procedure_stoixeia_update)
button_execute.pack()


button_close = tk.Button(window, text="Close Connection", command=close_connection)
button_close.pack()

window.mainloop()
