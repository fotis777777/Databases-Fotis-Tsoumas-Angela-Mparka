import mysql.connector
import tkinter as tk
from tkinter import ttk
import sys



from config import ID
from config import id_sm



# Establish connection to MySQL database
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()

root = tk.Tk()
root.title("Janitor Command Window")



text_output = tk.Text(root, font=("Arial", 9))# , width=150, height=30)
text_output.pack(side="left", fill="both", expand=True)






##################### QUERIES

def query321(titlos, suggrafeas, kathgoria, diathesima, id_sm):
    cursor.execute('''SELECT DISTINCT b.titlos, s.onoma_suggrafea, k.onoma_kathgorias, da.ar_diathesimwn
    FROM biblia b
    INNER JOIN exei_grapsei eg ON b.isbn = eg.isbn
    INNER JOIN suggrafeis s ON s.id_suggrafea = eg.id_suggrafea
    INNER JOIN anhkei an ON b.isbn = an.isbn
    INNER JOIN kathgories k ON k.id_kathgorias = an.id_kathgorias
    INNER JOIN diathesima_antitupa da ON b.isbn = da.isbn
    WHERE
        (b.titlos = %s OR %s = '')
        AND (s.onoma_suggrafea = %s OR %s = '')
        AND (k.onoma_kathgorias = %s OR %s = '')
        AND (da.ar_diathesimwn >= %s OR %s = '')
        AND id_sxolikis_monadas = %s;''', (titlos, titlos, suggrafeas, suggrafeas, kathgoria, kathgoria, diathesima, diathesima, id_sm))
    result = cursor.fetchall()
    cursor.nextset()
    return result



def query322():
    cursor.execute('''SELECT x.onoma, x.epwnumo, DATEDIFF(CURRENT_TIMESTAMP() - INTERVAL 7 DAY, dk.hm_daneismou) as delay, dk.isbn
    FROM Xristes x
    INNER JOIN daneismoi_kratiseis dk on dk.id_xristi = x.id_xristi
    WHERE (NOT dk.hm_daneismou BETWEEN DATE_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY) AND CURRENT_TIMESTAMP()) AND dk.hm_epistrofis IS NULL; ''')
    result = cursor.fetchall()
    cursor.nextset()
    return result

def query323(username, kathgoria):
    cursor.execute('''SELECT x.username, k.onoma_kathgorias, AVG(ak.bathmologia) AS avg_bathm
    FROM aksiologisi ak
    INNER JOIN anhkei a ON ak.isbn = a.isbn
    INNER JOIN biblia b ON a.isbn = b.isbn
    INNER JOIN kathgories k ON k.id_kathgorias = a.id_kathgorias
    INNER JOIN Xristes x ON x.id_xristi = ak.id_xristi
    WHERE (x.username = %s or %s = '')
    and (k.onoma_kathgorias = %s or %s = '')
    GROUP BY k.onoma_kathgorias;''', (username, username, kathgoria, kathgoria))
    result = cursor.fetchall()
    cursor.nextset()
    return result


def handle_query321():
    titlos = entry1.get()
    suggrafeas = entry2.get()
    kathgoria = entry3.get()
    diathesima = entry4.get()
    result = query321(titlos, suggrafeas, kathgoria, diathesima, id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_query322():
    result = query322()
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_query323():
    username = entry5_1.get()
    kathgoria = entry5_2.get()
    result = query323(username, kathgoria)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")



label1 = tk.Label(root, text="Query 321. Παρουσίαση όλων των βιβλίων")
label1.pack()

label_tit = tk.Label(root, text="Τίτλος:")
label_tit.pack()

entry1 = tk.Entry(root)
entry1.pack()

label_sug = tk.Label(root, text="Συγγραφέας:")
label_sug.pack()

entry2 = tk.Entry(root)
entry2.pack()

label_kat = tk.Label(root, text="Κατηγορία:")
label_kat.pack()

entry3 = tk.Entry(root)
entry3.pack()

label_da = tk.Label(root, text="Διαθέσιμα Αντιτυπα:")
label_da.pack()

entry4 = tk.Entry(root)
entry4.pack()

button1 = tk.Button(root, text="Run", command=handle_query321)
button1.pack()

label2del = tk.Label(root, text="Query 322. Καθυστερημενες Επιστροφες")
label2del.pack()

button2 = tk.Button(root, text="Run", command=handle_query322)
button2.pack()

label2 = tk.Label(root, text="Query 323. Μεση βαθμολογια ανα χρηστη και ανα κατηγορια")
label2.pack()

label2_1 = tk.Label(root, text="username:")
label2_1.pack()

entry5_1 = tk.Entry(root)
entry5_1.pack()

label2_2 = tk.Label(root, text="Κατηγορια:")
label2_2.pack()

entry5_2 = tk.Entry(root)
entry5_2.pack()

button3 = tk.Button(root, text="Run", command=handle_query323)
button3.pack()



##################### VIEWS


def view_curhol(id_sm):
    cursor.execute('''
    select isbn, titlos, id_xristi, onoma_xristi, epwnumo_xristi, hm_kratisis from SM_DK
    where id_sxolikis_monadas=%s and hm_daneismou is null;''', (id_sm,))
    result = cursor.fetchall()
    cursor.nextset()
    return result


def view_curdan(id_sm):
    cursor.execute('''
    select isbn, titlos, id_xristi,  onoma_xristi, epwnumo_xristi, hm_daneismou from SM_DK
    where id_sxolikis_monadas=%s and hm_daneismou is not null AND hm_epistrofis IS null;
    ''', (id_sm,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def view_curret(id_sm):
    cursor.execute('''
    select isbn, titlos, id_xristi,  onoma_xristi, epwnumo_xristi, hm_epistrofis from SM_DK
    where id_sxolikis_monadas=%s and hm_daneismou is not null AND hm_epistrofis is not null;
    ''', (id_sm,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def view_notret(id_sm):
    cursor.execute('''
    select isbn, titlos, id_xristi,  onoma_xristi, epwnumo_xristi, hm_daneismou, delay from SM_DK
    where id_sxolikis_monadas=%s and hm_daneismou is not null AND hm_epistrofis IS null;
    ''', (id_sm,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def view_delret(id_sm):
    cursor.execute('''
    select isbn, titlos, id_xristi,  onoma_xristi, epwnumo_xristi, hm_daneismou, hm_epistrofis, delay from SM_DK
    where id_sxolikis_monadas=%s and hm_daneismou is not null AND hm_epistrofis IS not null and DATEDIFF(hm_epistrofis - INTERVAL 7 DAY, hm_daneismou)>=0;
    ''', (id_sm,))
    result = cursor.fetchall()
    cursor.nextset()
    return result



def handle_view_curhol():
    result = view_curhol(id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_view_curdan():
    result = view_curdan(id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_view_curret():
    result = view_curret(id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_view_notret():
    result = view_notret(id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_view_delret():
    result = view_delret(id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")





label3 = tk.Label(root, text="Ολες οι τρεχουσες κρατησεις της Σχολικης Μοναδας")
label3.pack()

button4 = tk.Button(root, text="Run", command=handle_view_curhol)
button4.pack()


label4 = tk.Label(root, text="Ολοι οι τρεχοντες δανεισμοι της Σχολικης Μοναδας")
label4.pack()

button5 = tk.Button(root, text="Run", command=handle_view_curdan)
button5.pack()


label5 = tk.Label(root, text="Iστορικο δανεισμων που εχουν επιστραφει")
label5.pack()

button6 = tk.Button(root, text="Run", command=handle_view_curret)
button6.pack()


label6 = tk.Label(root, text="Λιστα επιστροφων που δεν εχουν γινει")
label6.pack()

button7 = tk.Button(root, text="Run", command=handle_view_notret)
button7.pack()

label7 = tk.Label(root, text="Ιστορικο Καθυστερημενων επιστροφων")
label7.pack()

button8 = tk.Button(root, text="Run", command=handle_view_delret)
button8.pack()


def view_akspub(id_sm):
    cursor.execute('''
    select id_aksiologisis, ISbn, titlos, onoma_xristi, epwnumo_xristi, hm_dhmiourgias, hm_egrisis, bathmologia, kritiki from SM_AKSIOLOGISEIS
    where id_sxolikis_monadas=%s and hm_egrisis is not null;    ''', (id_sm,))
    result = cursor.fetchall()
    cursor.nextset()
    return result


def view_aksnot(id_sm):
    cursor.execute('''
    select id_aksiologisis, ISbn, titlos, onoma_xristi, epwnumo_xristi, hm_dhmiourgias, bathmologia, kritiki from SM_AKSIOLOGISEIS
    where id_sxolikis_monadas=%s and hm_egrisis is null;    ''', (id_sm,))
    result = cursor.fetchall()
    cursor.nextset()
    return result


def handle_view_akspub():
    result = view_akspub(id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_view_aksnot():
    result = view_aksnot(id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

label8 = tk.Label(root, text="Δημοσιευμενες Αξιολογησεις")
label8.pack()

button9 = tk.Button(root, text="Run", command=handle_view_akspub)
button9.pack()

label9 = tk.Label(root, text="Αδημοσιευτες Αξιολογησεις")
label9.pack()

button10 = tk.Button(root, text="Run", command=handle_view_aksnot)
button10.pack()




root.mainloop()

cursor.close()
conn.close()
