import tkinter as tk
import mysql.connector




from config import ID
from config import id_sm





conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)


cursor = conn.cursor()



def execute_procedure_x_creation():

    username = entry_username.get()
    password = entry_password.get()
    onoma = entry_onoma.get()
    epwnumo = entry_epwnumo.get()
    hm_gennhshs = entry_hm_gennhshs.get()
    stud_prof = entry_stud_prof.get()
    is_admin = entry_is_admin.get()


    try:
        cursor.callproc('Xristis_Creation', (username, password, onoma, epwnumo, hm_gennhshs, stud_prof, is_admin, id_sm))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)



window = tk.Tk()
window.title("Execute SQL Procedure")


label_username = tk.Label(window, text="Username:")
label_username.pack()
entry_username = tk.Entry(window)
entry_username.pack()

label_password = tk.Label(window, text="Password:")
label_password.pack()
entry_password = tk.Entry(window)
entry_password.pack()

label_onoma = tk.Label(window, text="Onoma:")
label_onoma.pack()
entry_onoma = tk.Entry(window)
entry_onoma.pack()

label_epwnumo = tk.Label(window, text="Epwnumo:")
label_epwnumo.pack()
entry_epwnumo = tk.Entry(window)
entry_epwnumo.pack()

label_hm_gennhshs = tk.Label(window, text="Hm Gennisis (YYYY-MM-DD):")
label_hm_gennhshs.pack()
entry_hm_gennhshs = tk.Entry(window)
entry_hm_gennhshs.pack()

label_stud_prof = tk.Label(window, text="You will be: (1 - Teacher or 0 - Student)")
label_stud_prof.pack()
entry_stud_prof = tk.Entry(window)
entry_stud_prof.pack()

label_is_admin = tk.Label(window, text="You will be: (1 - Admin or 0 - User:")
label_is_admin.pack()
entry_is_admin = tk.Entry(window)
entry_is_admin.pack()


def close_connection():
    cursor.close()
    conn.close()
    print("Database connection closed.")


button_execute = tk.Button(window, text="Execute Procedure", command=execute_procedure_x_creation)
button_execute.pack()


button_close = tk.Button(window, text="Close Connection", command=close_connection)
button_close.pack()

window.mainloop()
