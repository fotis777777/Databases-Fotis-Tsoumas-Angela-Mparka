import tkinter as tk
import mysql.connector

conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()


def execute_procedure_biblio_creation():
    n_titlos = entry_titlos.get()
    n_ekdoths = entry_ekdoths.get()
    n_glwssa = entry_glwssa.get()
    n_selides = entry_selides.get()
    n_perilipsi = entry_perilipsi.get()
    n_isbn = entry_isbn.get()


    try:
        cursor.callproc('Biblio_Update', (n_titlos, n_ekdoths,n_glwssa ,n_selides,n_perilipsi, n_isbn))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)


window = tk.Tk()
window.title("Execute SQL Procedure")


label_titlos = tk.Label(window, text="Τιτλος:")
label_titlos.pack()
entry_titlos = tk.Entry(window)
entry_titlos.pack()

label_ekdoths = tk.Label(window, text="Εκδοτης:")
label_ekdoths.pack()
entry_ekdoths = tk.Entry(window)
entry_ekdoths.pack()

label_glwssa = tk.Label(window, text="Γλωσσα:")
label_glwssa.pack()
entry_glwssa = tk.Entry(window)
entry_glwssa.pack()

label_selides = tk.Label(window, text="Σελίδες:")
label_selides.pack()
entry_selides = tk.Entry(window)
entry_selides.pack()

label_perilipsi = tk.Label(window, text="Περιληψη:")
label_perilipsi.pack()
entry_perilipsi = tk.Entry(window)
entry_perilipsi.pack()

label_isbn = tk.Label(window, text="ISBN:")
label_isbn.pack()
entry_isbn = tk.Entry(window)
entry_isbn.pack()

button_execute = tk.Button(window, text="Execute Procedure", command=execute_procedure_biblio_creation)
button_execute.pack()


def close_connection():
    cursor.close()
    conn.close()
    window.destroy()

window.protocol("WM_DELETE_WINDOW", close_connection)
window.mainloop()
