import mysql.connector
import tkinter as tk
import sys




from config import ID
from config import id_sm



# Establish connection to MySQL database
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()

root = tk.Tk()

def query311(hm1, hm2):
    cursor.execute('''SELECT sm.onomasia_sm, COUNT(dk.id_dk)
                      FROM Sxoliki_Monada sm
                      INNER JOIN anhkei_SM asm ON asm.id_sxolikis_monadas = sm.id_sxolikis_monadas
                      INNER JOIN Xristes x ON x.id_xristi = asm.id_xristi
                      INNER JOIN daneismoi_kratiseis dk ON dk.id_xristi = x.id_xristi
                      WHERE dk.hm_daneismou BETWEEN %s AND %s AND dk.hm_daneismou IS NOT NULL
                      GROUP BY sm.onomasia_sm ;''', (hm1, hm2))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def query3121(onoma_kathgorias):
    cursor.execute('''select distinct s.onoma_suggrafea
    from suggrafeis s
    inner join exei_grapsei eg on s.id_suggrafea=eg.id_suggrafea
    inner join anhkei an on an.isbn=eg.isbn
    inner join kathgories k on an.id_kathgorias=k.id_kathgorias
    inner join daneismoi_kratiseis dk on eg.isbn=dk.isbn
    where k.onoma_kathgorias= %s and DATEDIFF(CURDATE(), dk.hm_daneismou) < 365;''', (onoma_kathgorias,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def query3122(onoma_kathgorias):
    cursor.execute('''select distinct x.onoma, x.epwnumo
    from Xristes x
    inner join daneismoi_kratiseis dk on x.id_xristi=dk.id_xristi
    inner join anhkei an on an.isbn=dk.isbn
    inner join kathgories k on an.id_kathgorias=k.id_kathgorias
    where k.onoma_kathgorias=%s and DATEDIFF(CURDATE(), dk.hm_daneismou) < 365;''', (onoma_kathgorias,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def query313():
    cursor.execute(''' select x.onoma, x.epwnumo, count(*)
        from Xristes x
        inner join daneismoi_kratiseis dk on dk.id_xristi=x.id_xristi
        where (select DATE_SUB(CURRENT_DATE(), INTERVAL 40 YEAR)) >= x.hm_gennhshs and x.stud_prof=1 and hm_daneismou is not NULL
        group by x.id_xristi
        ORDER BY count(*) DESC; ''')
    result = cursor.fetchall()
    cursor.nextset()
    return result

def query314():
    cursor.execute(''' select s.onoma_suggrafea
    FROM suggrafeis s
      except(select s.onoma_suggrafea
      from suggrafeis s
      inner join exei_grapsei eg on s.id_suggrafea =  eg.id_suggrafea
      inner join daneismoi_kratiseis dk on dk.isbn=eg.isbn
      where dk.hm_daneismou is not null);''')
    result = cursor.fetchall()
    cursor.nextset()
    return result


def query315():
    cursor.execute(''' SELECT dcount1.onoma, dcount1.epwnumo, dcount1.daneismoi
    FROM (
        SELECT x.onoma, x.epwnumo, COUNT(dk.id_DK) as daneismoi
        FROM xristes x
        INNER JOIN Einai_Xeiristis ex ON x.id_xristi = ex.id_xristi
        INNER JOIN Sxoliki_Monada sm ON ex.id_sxolikis_monadas = sm.id_sxolikis_monadas
        INNER JOIN anhkei_SM asm ON asm.id_sxolikis_monadas = sm.id_sxolikis_monadas
        INNER JOIN xristes x2 ON asm.id_xristi = x2.id_xristi
        INNER JOIN daneismoi_kratiseis dk ON x2.id_xristi = dk.id_xristi
        WHERE dk.hm_daneismou BETWEEN '2022-01-01' AND '2023-01-01'
        GROUP BY x.id_xristi
        HAVING daneismoi >= 5
    ) AS dcount1
    inner join
    (
      SELECT x.onoma, x.epwnumo, COUNT(dk.id_DK) as daneismoi
      FROM xristes x
      INNER JOIN Einai_Xeiristis ex ON x.id_xristi = ex.id_xristi
      INNER JOIN Sxoliki_Monada sm ON ex.id_sxolikis_monadas = sm.id_sxolikis_monadas
      INNER JOIN anhkei_SM asm ON asm.id_sxolikis_monadas = sm.id_sxolikis_monadas
      INNER JOIN xristes x2 ON asm.id_xristi = x2.id_xristi
      INNER JOIN daneismoi_kratiseis dk ON x2.id_xristi = dk.id_xristi
      WHERE dk.hm_daneismou BETWEEN '2022-01-01' AND '2023-01-01'
      GROUP BY x.id_xristi
      HAVING daneismoi >= 5
    )as dcount2
    on dcount1.daneismoi=dcount2.daneismoi
    where dcount1.onoma!=dcount2.onoma and dcount1.epwnumo!=dcount2.epwnumo;''')
    result = cursor.fetchall()
    cursor.nextset()
    return result

def query316():
    cursor.execute(''' SELECT distinct k1.onoma_kathgorias, k2.onoma_kathgorias, count(distinct dk.isbn) as daneismena
    from daneismoi_kratiseis dk
    INNER JOIN anhkei a1 ON dk.isbn = a1.isbn
    INNER JOIN kathgories k1 ON a1.id_kathgorias = k1.id_kathgorias
    INNER JOIN anhkei a2 ON dk.isbn = a2.isbn
    INNER JOIN kathgories k2 ON a2.id_kathgorias = k2.id_kathgorias AND k2.id_kathgorias != k1.id_kathgorias
    where dk.hm_daneismou is not null
    group by  concat(least(k1.onoma_kathgorias, k2.onoma_kathgorias), ' - ', greatest(k1.onoma_kathgorias, k2.onoma_kathgorias))
    ORDER BY daneismena DESC
    LIMIT 3; ''')
    result = cursor.fetchall()
    cursor.nextset()
    return result

def query317():
    cursor.execute(''' SELECT s.onoma_suggrafea, COUNT(b.titlos) as grammena
    FROM suggrafeis s
    INNER JOIN exei_grapsei eg ON s.id_suggrafea = eg.id_suggrafea
    INNER JOIN biblia b ON eg.isbn = b.isbn
    GROUP BY s.id_suggrafea
    HAVING grammena <= (
      SELECT MAX(cnt) - 5
      FROM (
        SELECT COUNT(*) as cnt
        FROM exei_grapsei
        GROUP BY id_suggrafea) as counts)
    ORDER BY grammena DESC; ''')
    result = cursor.fetchall()
    cursor.nextset()
    return result

def handle_query311():
    hm1 = entry1.get()
    hm2 = entry2.get()
    result = query311(hm1, hm2)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_query3121():
    onoma_kathgorias = entry3.get()
    result = query3121(onoma_kathgorias)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_query3122():
    onoma_kathgorias = entry4.get()
    result = query3122(onoma_kathgorias)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_query313():
    result = query313()
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_query314():
    result = query314()
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_query315():
    result = query315()
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_query316():
    result = query316()
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

def handle_query317():
    result = query317()
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")



label1 = tk.Label(root, text="Query 311. Παρουσίαση λίστας με συνολικό αριθμό δανεισμών ανά σχολείο")
label1.pack()

label_hm1 = tk.Label(root, text="Ημερομηνια Εναρξης (ΥΥΥΥ-ΜΜ-DD):")
label_hm1.pack()

entry1 = tk.Entry(root)
entry1.pack()

label_hm2 = tk.Label(root, text="Ημερομηνια Ληξης (ΥΥΥΥ-ΜΜ-DD):")
label_hm2.pack()

entry2 = tk.Entry(root)
entry2.pack()

button1 = tk.Button(root, text="Run", command=handle_query311)
button1.pack()

label2 = tk.Label(root, text="Query 3121. Ποιοι συγγραφείς ανήκουν σε αυτήν την κατηγορία")
label2.pack()

label_onoma_kathgorias = tk.Label(root, text="Όνομα Κατηγορίας:")
label_onoma_kathgorias.pack()

entry3 = tk.Entry(root)
entry3.pack()

button2 = tk.Button(root, text="Run", command=handle_query3121)
button2.pack()

label3 = tk.Label(root, text="Query 3122. Ποιοι εκπαιδευτικοί έχουν δανειστεί βιβλία αυτής της κατηγορίας")
label3.pack()

label_onoma_kathgorias2 = tk.Label(root, text="Όνομα Κατηγορίας:")
label_onoma_kathgorias2.pack()

entry4 = tk.Entry(root)
entry4.pack()

button3 = tk.Button(root, text="Run", command=handle_query3122)
button3.pack()

label4 = tk.Label(root, text="Query 313. Βρείτε τους νέους εκπαιδευτικούς που έχουν δανειστεί τα περισσότερα βιβλία.")
label4.pack()

button4 = tk.Button(root, text="Run", command=handle_query313)
button4.pack()

label5 = tk.Label(root, text="Query 314. Βρείτε τους συγγραφείς των οποίων κανένα βιβλίο δεν έχει τύχει δανεισμού.")
label5.pack()

button5 = tk.Button(root, text="Run", command=handle_query314)
button5.pack()

label6 = tk.Label(root, text="Query 315. Ποιοι χειριστές έχουν δανείσει τον ίδιο αριθμό βιβλίων σε διάστημα ενός έτους με περισσότερους από 20 δανεισμούς. ")
label6.pack()

button6 = tk.Button(root, text="Run", command=handle_query315)
button6.pack()

label7 = tk.Label(root, text="Query 316. Τα 3 κορυφαία ζεύγη που εμφανίστηκαν σε δανεισμούς. ")
label7.pack()

button7 = tk.Button(root, text="Run", command=handle_query316)
button7.pack()

label8 = tk.Label(root, text="Query 317. Ολοι οι συγγραφείς που έχουν γράψει τουλάχιστον 5 βιβλία λιγότερα από τον συγγραφέα με τα περισσότερα βιβλία. ")
label8.pack()

button8 = tk.Button(root, text="Run", command=handle_query317)
button8.pack()


def view_applied():
    cursor.execute('''select * from X_applied_sm;''' )
    result = cursor.fetchall()
    cursor.nextset()
    return result

def handle_view_applied():
    result = view_applied()
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

label8 = tk.Label(root, text="Αιτησεις Χειριστων Σχολικων Μοναδων ")
label8.pack()

button8 = tk.Button(root, text="Run", command=handle_view_applied)
button8.pack()




text_output = tk.Text(root)
text_output.pack()

root.mainloop()

cursor.close()
conn.close()
