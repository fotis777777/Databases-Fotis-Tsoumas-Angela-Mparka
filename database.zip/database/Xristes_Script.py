import mysql.connector
import tkinter as tk
from tkinter import ttk
import sys
import mysql.connector
import os
import subprocess


from config import ID
from config import id_sm





conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()

root = tk.Tk()
root.title("Janitor Command Window")

text_output = tk.Text(root, font=("Arial", 9), width=150, height=30)
text_output.pack(side="left", fill="both", expand=True)


def query331(titlos, sugrafeas, kathgoria, id_sm):
    cursor.execute(
        '''SELECT DISTINCT b.isbn, b.titlos, da.ar_diathesimwn
        FROM biblia b
        INNER JOIN anhkei an ON b.isbn=an.isbn
        INNER JOIN kathgories k ON an.id_kathgorias=k.id_kathgorias
        INNER JOIN exei_grapsei eg ON b.isbn=eg.isbn
        INNER JOIN suggrafeis s ON s.id_suggrafea=eg.id_suggrafea
        INNER JOIN diathesima_antitupa da ON da.isbn = b.isbn
        WHERE (b.titlos = %s OR %s = '')
        AND (s.onoma_suggrafea = %s OR %s = '')
        AND (k.onoma_kathgorias = %s OR %s = '')
        AND da.id_sxolikis_monadas = %s; ''',
        (titlos, titlos, sugrafeas, sugrafeas, kathgoria, kathgoria, id_sm)
    )
    result = cursor.fetchall()
    cursor.nextset()
    return result


def query332(ID):
    cursor.execute(
        '''SELECT b.isbn, b.titlos, dk.hm_daneismou, dk.hm_epistrofis
        FROM biblia b
        INNER JOIN daneismoi_kratiseis dk ON b.isbn=dk.isbn
        INNER JOIN Xristes x ON x.id_xristi=dk.id_xristi
        WHERE x.id_xristi=%s ; ''',
        (ID,)
    )
    result = cursor.fetchall()
    cursor.nextset()
    return result


def handle_query331():
    titlos = entry_t.get()
    sugrafeas = entry_s.get()
    kathgoria = entry_k.get()
    result = query331(titlos, sugrafeas, kathgoria, id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")


def handle_query332():
    result = query332(ID)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")


label_q1 = tk.Label(root, text="Query 331")
label_q1.pack()

label_t = tk.Label(root, text="Τιτλος:")
label_t.pack()

entry_t = tk.Entry(root)
entry_t.pack()

label_s = tk.Label(root, text="Συγγραφέας:")
label_s.pack()

entry_s = tk.Entry(root)
entry_s.pack()

label_k = tk.Label(root, text="Κατηγορία:")
label_k.pack()

entry_k = tk.Entry(root)
entry_k.pack()

button20 = tk.Button(root, text="Run", command=handle_query331)
button20.pack()

label_q2 = tk.Label(root, text="Query 332")
label_q2.pack()

button21 = tk.Button(root, text="Run", command=handle_query332)
button21.pack()


def view_biblia_sm():
    cursor.execute(
        '''SELECT da.id_sxolikis_monadas , w.titlos , w.isbn , w.categories , GROUP_CONCAT(s.onoma_suggrafea SEPARATOR ', ') AS suggrafeis
        FROM (  SELECT b.isbn, b.titlos , GROUP_CONCAT(k.onoma_kathgorias SEPARATOR ', ') AS categories
                FROM biblia b
                INNER JOIN anhkei a ON b.isbn = a.isbn
                INNER JOIN kathgories k ON a.id_kathgorias = k.id_kathgorias
                GROUP BY b.isbn )w
        INNER JOIN exei_grapsei eg ON w.isbn = eg.isbn
        INNER JOIN suggrafeis s ON eg.id_suggrafea = s.id_suggrafea
        INNER JOIN diathesima_antitupa da on  w.isbn = da.isbn
        where da.id_sxolikis_monadas = %s
        GROUP BY w.isbn; ''',
        (id_sm,)
    )
    result = cursor.fetchall()
    cursor.nextset()
    return result


def handle_view_biblia_sm():
    result = view_biblia_sm()
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")


def view_biblia_isbn():
    isbn = entry11.get()
    cursor.execute(
        '''SELECT titlos, isbn, onoma_kathgorias, onoma_suggrafea, diathesima FROM Biblio_data
        WHERE isbn = %s ;''',
        (isbn, )
    )
    result = cursor.fetchall()
    cursor.nextset()
    return result


def handle_view_biblia_isbn():
    result = view_biblia_isbn()
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")


label20 = tk.Label(root, text="Βιβλιοθήκη Σχολικής Μονάδας")
label20.pack()

button20 = tk.Button(root, text="Run", command=handle_view_biblia_sm)
button20.pack()

label18 = tk.Label(root, text="Αναζήτηση Βιβλίου")
label18.pack()

label19 = tk.Label(root, text="ISBN:")
label19.pack()

entry11 = tk.Entry(root)
entry11.pack()

button21 = tk.Button(root, text="Run", command=handle_view_biblia_isbn)
button21.pack()


def view_akspub(id_sm):
    cursor.execute(
        '''SELECT id_aksiologisis, ISbn, titlos, onoma_xristi, epwnumo_xristi, hm_dhmiourgias, hm_egrisis, bathmologia, kritiki
        FROM SM_AKSIOLOGISEIS
        WHERE id_sxolikis_monadas=%s AND hm_egrisis IS NOT NULL;''',
        (id_sm,)
    )
    result = cursor.fetchall()
    cursor.nextset()
    return result


def handle_view_akspub():
    result = view_akspub(id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")


label8 = tk.Label(root, text="Δημοσιευμένες Αξιολογήσεις")
label8.pack()

button9 = tk.Button(root, text="Run", command=handle_view_akspub)
button9.pack()



def view_sm_data(id_sm):
    cursor.execute(
        '''SELECT * from Sxoliki_Monada where id_sxolikis_monadas = %s ;''', (id_sm,) )
    result = cursor.fetchall()
    cursor.nextset()
    return result


def handle_view_sm_data():
    result = view_sm_data(id_sm)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")


label8 = tk.Label(root, text="Στοιχεια Σχολικης Μοναδας")
label8.pack()

button9 = tk.Button(root, text="Run", command=handle_view_sm_data)
button9.pack()





root.mainloop()

cursor.close()
conn.close()
