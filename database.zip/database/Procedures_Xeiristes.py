import tkinter as tk
import mysql.connector



from config import ID
from config import id_sm




conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()

id_sm = 1
ID = 1

window = tk.Tk()
window.title("Διαδικασιες Χειριστων ")

def execute_daneismos_creation_instant():
    id_xristi = entry_id_xristi1.get()
    isbn = entry_isbn1.get()

    try:
        cursor.execute("INSERT INTO Daneismoi_Kratiseis (id_xristi, isbn, hm_kratisis, hm_daneismou, hm_epistrofis, last_update) VALUES (%s, %s, NULL, CURRENT_TIMESTAMP(), NULL, CURRENT_TIMESTAMP());", (id_xristi, isbn))
        conn.commit()
        print("Query executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing query:", error)


label_daneismos_creation_instant = tk.Label(window, text="Δημιουργία Δανεισμού Αμεση")
label_daneismos_creation_instant.pack()

label_id_xristi1 = tk.Label(window, text="id Χρήστη:")
label_id_xristi1.pack()

entry_id_xristi1 = tk.Entry(window)
entry_id_xristi1.pack()

label_isbn1 = tk.Label(window, text="ISBN:")
label_isbn1.pack()

entry_isbn1 = tk.Entry(window)
entry_isbn1.pack()

button_daneismos_creation_instant = tk.Button(window, text="Run", command=execute_daneismos_creation_instant)
button_daneismos_creation_instant.pack()



def execute_daneismos_creation_update():
    id_xristi = entry_id_xristi2.get()
    isbn = entry_isbn2.get()

    try:
        cursor.execute("UPDATE Daneismoi_Kratiseis SET hm_daneismou = CURRENT_TIMESTAMP() WHERE hm_kratisis IS NOT NULL AND id_xristi = %s AND isbn = %s;", (id_xristi, isbn))
        conn.commit()
        print("Query executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing query:", error)

label_daneismos_creation_update = tk.Label(window, text="Δημιουργία Δανεισμού απο κρατηση")
label_daneismos_creation_update.pack()

label_id_xristi2 = tk.Label(window, text="id Χρήστη:")
label_id_xristi2.pack()

entry_id_xristi2 = tk.Entry(window)
entry_id_xristi2.pack()

label_isbn2 = tk.Label(window, text="ISBN:")
label_isbn2.pack()

entry_isbn2 = tk.Entry(window)
entry_isbn2.pack()

button_daneismos_creation_update = tk.Button(window, text="Run", command=execute_daneismos_creation_update)
button_daneismos_creation_update.pack()


def execute_epistrofh_update():
    id_xristi = entry_id_xristi3.get()
    isbn = entry_isbn3.get()

    try:
        cursor.execute("""UPDATE Daneismoi_Kratiseis SET hm_epistrofis = CURRENT_TIMESTAMP()
        WHERE hm_daneismou IS NOT NULL AND id_xristi = %s AND isbn = %s;""", (id_xristi, isbn))
        conn.commit()
        print("Query executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing query:", error)

label_epistrofh_update = tk.Label(window, text="Επιστροφή Αντιτύπου")
label_epistrofh_update.pack()

label_id_xristi3 = tk.Label(window, text="ID Χρήστη:")
label_id_xristi3.pack()

entry_id_xristi3 = tk.Entry(window)
entry_id_xristi3.pack()

label_isbn3 = tk.Label(window, text="ISBN:")
label_isbn3.pack()

entry_isbn3 = tk.Entry(window)
entry_isbn3.pack()

button_epistrofh_update = tk.Button(window, text="Run", command=execute_epistrofh_update)
button_epistrofh_update.pack()

def execute_ban_user():
    id_xristi = entry_id_xristi4.get()

    try:
        cursor.execute("INSERT INTO BANNED_USER_IDS (banned_id) VALUES (%s);", (id_xristi,))
        conn.commit()
        print("Query executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing query:", error)

label_ban_user = tk.Label(window, text="Αποκλεισμος Χρήστη")
label_ban_user.pack()

label_id_xristi4 = tk.Label(window, text="id Χρήστη:")
label_id_xristi4.pack()

entry_id_xristi4 = tk.Entry(window)
entry_id_xristi4.pack()

button_ban_user = tk.Button(window, text="Run", command=execute_ban_user)
button_ban_user.pack()



def execute_unban_user():
    id_xristi = entry_id_xristi5.get()

    try:
        cursor.execute("DELETE FROM BANNED_USER_IDS WHERE banned_id = %s;", (id_xristi,))
        conn.commit()
        print("Query executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing query:", error)

label_unban_user = tk.Label(window, text="Αναίρεση Αποκλεισμου Χρήστη")
label_unban_user.pack()

label_id_xristi5 = tk.Label(window, text="id Χρήστη:")
label_id_xristi5.pack()

entry_id_xristi5 = tk.Entry(window)
entry_id_xristi5.pack()

button_unban_user = tk.Button(window, text="Run", command=execute_unban_user)
button_unban_user.pack()



def execute_diathesima_update():

    n_diathesima = entry_n_diathesima.get()
    isbn  = entry_isbn6.get()

    try:
        cursor.execute('''UPDATE Diathesima_Antitupa
        SET ar_diathesimwn = ar_diathesimwn + %s
        WHERE ISBN = %s and   id_sxolikis_monadas=%s; ''', (n_diathesima, isbn, id_sm))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)

label_appl = tk.Label(window, text="Ενημερωση διαθεσιμων ")
label_appl.pack()



label_d = tk.Label(window, text="Διαθεσιμα (Αυξηση/Μειωση): ")
label_d.pack()

entry_n_diathesima = tk.Entry(window)
entry_n_diathesima.pack()

label_d = tk.Label(window, text="ISBN: ")
label_d.pack()

entry_isbn6 = tk.Entry(window)
entry_isbn6.pack()


button_appl = tk.Button(window, text="Run", command=execute_diathesima_update)
button_appl.pack()


def execute_delete_rating():

    id_aks = entry_ida.get()

    try:
        cursor.execute('''delete from aksiologisi where id_aksiologisis = %s ''', (id_aks,))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)

label_aksd = tk.Label(window, text="Διαγραφη Αξιολογησης ")
label_aksd.pack()



label_ida = tk.Label(window, text="id Αξιολογησης: ")
label_ida.pack()

entry_ida = tk.Entry(window)
entry_ida.pack()


button_appl = tk.Button(window, text="Run", command=execute_delete_rating)
button_appl.pack()


window.mainloop()
