import tkinter as tk
import mysql.connector



conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)


cursor = conn.cursor()


def execute_procedure_xeir_approve():

    id_xristi = entry_id.get()


    cursor.execute('''    UPDATE Einai_Xeiristis
                          SET hm_lixis = CURRENT_TIMESTAMP
                          WHERE id_sxolikis_monadas = ( SELECT asm.id_sxolikis_monadas
                                  FROM anhkei_SM asm
                                  INNER JOIN Xristes x ON asm.id_xristi = x.id_xristi
                                  WHERE x.id_xristi = %s
                                  ) AND id_xristi != %s;''', (id_xristi, id_xristi))

    cursor.execute( '''
            INSERT INTO `Einai_Xeiristis` (`id_sxolikis_monadas`, `id_xristi`, `hm_enarxis`, `hm_lixis`, `last_update`)
            VALUES (( SELECT asm.id_sxolikis_monadas
                                  FROM anhkei_SM asm
                                  INNER JOIN Xristes x ON asm.id_xristi = x.id_xristi
                                  WHERE x.id_xristi = %s),
                                  %s,  current_timestamp, NULL,  current_timestamp);''' , (id_xristi, id_xristi))
    conn.commit()

window = tk.Tk()
window.title("Αποδοχη Χειριστη ")


label_username = tk.Label(window, text="id Χρηστη:")
label_username.pack()
entry_id = tk.Entry(window)
entry_id.pack()

button_execute = tk.Button(window, text="Execute Procedure", command=execute_procedure_xeir_approve)
button_execute.pack()


window.mainloop()

cursor.close()
conn.close()
