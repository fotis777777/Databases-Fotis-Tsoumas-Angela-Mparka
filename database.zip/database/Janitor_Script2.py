import mysql.connector
import tkinter as tk
from tkinter import ttk
import sys



from config import ID
from config import id_sm




# Establish connection to MySQL database
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()

root = tk.Tk()
root.title("Janitor Command Window 2")



text_output = tk.Text(root, font=("Arial", 9))# , width=150, height=30)
text_output.pack(side="left", fill="both", expand=True)






def view_krat_xr(username):
    cursor.execute('''
    select isbn, titlos, username, hm_kratisis from X_DK
    where username=%s and hm_daneismou is null;    ''', (username,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def handle_view_krat_xr():
    username=entry6.get()
    result = view_krat_xr(username)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

label10 = tk.Label(root, text="Κρατησεις Χρηστη")
label10.pack()

label11 = tk.Label(root, text="Username:")
label11.pack()


entry6 = tk.Entry(root)
entry6.pack()


button11 = tk.Button(root, text="Run", command=handle_view_krat_xr)
button11.pack()



def view_dan_xr(username):
    cursor.execute('''
    select isbn, titlos, username, hm_daneismou from X_DK
    where username=%s and hm_daneismou is not null AND hm_epistrofis IS null;    ''', (username,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def handle_view_dan_xr():
    username = entry7.get()
    result = view_dan_xr(username)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

label12 = tk.Label(root, text="Δανεισμοι Χρηστη")
label12.pack()

label13 = tk.Label(root, text="Username:")
label13.pack()

entry7 = tk.Entry(root)
entry7.pack()

button12 = tk.Button(root, text="Run", command=handle_view_dan_xr)
button12.pack()



def view_ep_xr(username):
    cursor.execute('''
    select isbn, titlos, username, hm_epistrofis from X_DK
    where username=%s and hm_daneismou is not null AND hm_epistrofis IS not null;    ''', (username,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def handle_view_ep_xr():
    username = entry8.get()
    result = view_ep_xr(username)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

label14 = tk.Label(root, text="Επιστροφες Χρηστη")
label14.pack()

label15 = tk.Label(root, text="Username:")
label15.pack()

entry8 = tk.Entry(root)
entry8.pack()

button13 = tk.Button(root, text="Run", command=handle_view_ep_xr)
button13.pack()




def view_delays(username):
    cursor.execute('''
    select isbn, titlos, id_xristi,  hm_daneismou, delay from X_delays
    where username=%s and hm_daneismou is not null AND hm_epistrofis IS null;    ''', (username,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def handle_view_delays():
    username=entry9.get()
    result = view_delays(username)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

label16 = tk.Label(root, text="Καθυστερημενες Επιστροφες Χρηστων")
label16.pack()

label17 = tk.Label(root, text="Username:")
label17.pack()

entry9 = tk.Entry(root)
entry9.pack()


button14 = tk.Button(root, text="Run", command=handle_view_delays)
button14.pack()

def view_delays_hist(username):
    cursor.execute('''
    select isbn, titlos, id_xristi, hm_daneismou, hm_epistrofis, delay from X_delays
    where username=%s and hm_daneismou is not null AND hm_epistrofis IS not null and DATEDIFF(hm_epistrofis - INTERVAL 7 DAY, hm_daneismou)>=0;
    ''', (username,))
    result = cursor.fetchall()
    cursor.nextset()
    return result

def handle_view_delays_hist():
    username = entry10.get()
    result = view_delays_hist(username)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

label18 = tk.Label(root, text="Ιστορικο με Καθυστερημενες Επιστροφες Χρηστων")
label18.pack()


label19 = tk.Label(root, text="Username:")
label19.pack()

entry10 = tk.Entry(root)
entry10.pack()


button15 = tk.Button(root, text="Run", command=handle_view_delays_hist)
button15.pack()


def view_banned(username):
    cursor.execute(''' select * from X_banned; ''')
    result = cursor.fetchall()
    cursor.nextset()
    return result

def handle_view_banned():
    result = view_delays_hist(username)
    text_output.delete(1.0, tk.END)
    for item in result:
        text_output.insert(tk.END, f"{item}\n")

label18 = tk.Label(root, text="Αποκλεισμενοι Χρηστες: ")
label18.pack()

button15 = tk.Button(root, text="Run", command=handle_view_delays_hist)
button15.pack()




root.mainloop()

cursor.close()
conn.close()
