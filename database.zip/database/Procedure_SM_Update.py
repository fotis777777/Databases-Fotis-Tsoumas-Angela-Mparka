import tkinter as tk
import mysql.connector

conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='library'
)

cursor = conn.cursor()


def execute_procedure_SM_update():
    n_onomasia_sm = entry_n_onomasia_sm.get()
    n_TK = entry_n_TK.get()
    n_Polh = entry_n_Polh.get()
    n_Thlefwno = entry_n_Thlefwno.get()
    n_email = entry_n_email.get()
    n_onoma_dieuthunti = entry_n_onoma_dieuthunti.get()
    id_sm = entry_id_sm.get()


    try:
        cursor.callproc('Sxoliki_Monada_Update', (n_onomasia_sm, n_TK, n_Polh, n_Thlefwno, n_email, n_onoma_dieuthunti, id_sm))
        conn.commit()
        print("Procedure executed successfully!")
    except mysql.connector.Error as error:
        print("Error executing procedure:", error)


window = tk.Tk()
window.title("Execute SQL Procedure")



label_id_sm = tk.Label(window, text="Ταυτοτητα(id) :")
label_id_sm.pack()

entry_id_sm = tk.Entry(window)
entry_id_sm.pack()

label_n_onomasia_sm = tk.Label(window, text="Όνομασία ΣΜ:")
label_n_onomasia_sm.pack()

entry_n_onomasia_sm = tk.Entry(window)
entry_n_onomasia_sm.pack()

label_n_TK = tk.Label(window, text="Τ.Κ.:")
label_n_TK.pack()

entry_n_TK = tk.Entry(window)
entry_n_TK.pack()

label_n_Polh = tk.Label(window, text="Πόλη:")
label_n_Polh.pack()

entry_n_Polh = tk.Entry(window)
entry_n_Polh.pack()

label_n_Thlefwno = tk.Label(window, text="Τηλέφωνο:")
label_n_Thlefwno.pack()

entry_n_Thlefwno = tk.Entry(window)
entry_n_Thlefwno.pack()

label_n_email = tk.Label(window, text="Email:")
label_n_email.pack()

entry_n_email = tk.Entry(window)
entry_n_email.pack()

label_n_onoma_dieuthunti = tk.Label(window, text="Ονοματεπώνυμο Διευθυντή:")
label_n_onoma_dieuthunti.pack()

entry_n_onoma_dieuthunti = tk.Entry(window)
entry_n_onoma_dieuthunti.pack()

button_execute = tk.Button(window, text="Execute Procedure", command=execute_procedure_SM_update)
button_execute.pack()







def close_connection():
    cursor.close()
    conn.close()
    window.destroy()

window.protocol("WM_DELETE_WINDOW", close_connection)
window.mainloop()
